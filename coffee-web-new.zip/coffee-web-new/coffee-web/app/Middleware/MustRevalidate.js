'use strict'
/** @typedef {import('@adonisjs/framework/src/Request')} Request */
/** @typedef {import('@adonisjs/framework/src/Response')} Response */
/** @typedef {import('@adonisjs/framework/src/View')} View */

class MustRevalidate {
  /**
   * @param {object} ctx
   * @param {Request} ctx.request
   * @param {Function} next
   */
  async handle ({ request, response }, next) {
    // call next to advance the request
    response.header('Cache-Control', 'nocache, no-store, max-age=0, must-revalidate')
    response.header('Pragma', 'no-cache')
    response.header('Expires', 'Fri, 01 Jan 1990 00:00:00 GMT')
    await next()
  }
}

module.exports = MustRevalidate
