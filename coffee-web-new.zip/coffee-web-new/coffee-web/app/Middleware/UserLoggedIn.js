'use strict'
/** @typedef {import('@adonisjs/framework/src/Request')} Request */
/** @typedef {import('@adonisjs/framework/src/Response')} Response */
/** @typedef {import('@adonisjs/framework/src/View')} View */
const SelfHelpers = use('App/Services/SelfHelpers')

class UserLoggedIn {
  /**
   * @param {object} ctx
   * @param {Request} ctx.request
   * @param {Function} next
   */
  async handle({ request, response, auth }, next) {
    // call next to advance the request

    try {
      if (await auth.check()) {
        const role_id = auth.user.role_id
        const return_to = SelfHelpers.getRetunrRoute(role_id)
        return response.redirect(return_to);
      }
    } catch (err) {
      return view.render("auth.customer-login");
    }

    await next()
  }
}

module.exports = UserLoggedIn
