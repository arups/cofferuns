'use strict'
/** @typedef {import('@adonisjs/framework/src/Request')} Request */
/** @typedef {import('@adonisjs/framework/src/Response')} Response */
/** @typedef {import('@adonisjs/framework/src/View')} View */

class RetailCustomer {
  /**
   * @param {object} ctx
   * @param {Request} ctx.request
   * @param {Function} next
   */
  async handle({ request, session, auth, response }, next) {
    // call next to advance the request
    const role_id = auth.user.role_id
    if (role_id != 4) {
      session.flash({ type: 'danger', message: "Permissions denied!" })
      return response.redirect('/')
    }

    await next()
  }
}

module.exports = RetailCustomer
