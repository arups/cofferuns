'use strict'

/** @type {typeof import('@adonisjs/lucid/src/Lucid/Model')} */
const Model = use('Model')

class OrderTime extends Model {

    orders() {
        return this.hasMany('App/Models/Orders')
    }
    static get hidden() {
        return ['created_at', 'updated_at', 'is_deleted'];
    }
}

module.exports = OrderTime
