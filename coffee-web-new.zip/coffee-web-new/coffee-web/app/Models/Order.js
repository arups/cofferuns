'use strict'

/** @type {typeof import('@adonisjs/lucid/src/Lucid/Model')} */
const Model = use('Model')

class Order extends Model {
    order_items() {
        return this.hasMany('App/Models/OrderItem')
    }
    static get hidden() {
        return ['updated_at', 'is_deleted'];
    }

    getCreatedAt(value) {
        var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        var d = new Date(value),
            month = '' + (d.getMonth()),
            day = '' + d.getDate(),
            year = d.getFullYear();
        if (day.length < 2)
            day = '0' + day;
        return `${day} ${months[month]}, ${year}`
    }
}

module.exports = Order
