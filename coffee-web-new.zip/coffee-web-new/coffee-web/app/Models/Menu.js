'use strict'

/** @type {typeof import('@adonisjs/lucid/src/Lucid/Model')} */
const Model = use('Model')

class Menu extends Model {
    static boot() {
        super.boot()
        this.addGlobalScope(function (builder) {
            builder.where('is_deleted', '!=', 1)
        })
    }


    order_items() {
        return this.hasMany('App/Models/OrderItem')
    }
}

module.exports = Menu
