'use strict'

/** @type {typeof import('@adonisjs/lucid/src/Lucid/Model')} */
const Model = use('Model')

class Hour extends Model {

    static get hidden() {
        return ['created_at', 'updated_at', 'is_deleted'];
    }
}

module.exports = Hour
