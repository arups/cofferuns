'use strict'

/** @type {typeof import('@adonisjs/lucid/src/Lucid/Model')} */
const Model = use('Model')

class OrderItem extends Model {
    order() {
        return this.belongsTo('App/Models/Order')
    }

    menu() {
        return this.belongsTo('App/Models/Menu', 'product_id')
    }

    static get hidden() {
        return ['created_at', 'updated_at', 'is_deleted'];
    }
}

module.exports = OrderItem
