'use strict'
const MenuCategory = use('App/Models/MenuCategory')
const Menu = use('App/Models/Menu')
const Hour = use('App/Models/Hour')
const WeekDay = use('App/Models/WeekDay')
const MerchantBusinessHour = use('App/Models/MerchantBusinessHour')
const MerchantDetail = use('App/Models/MerchantDetail')
const Order = use('App/Models/Order')
const OrderItem = use('App/Models/OrderItem')
const User = use('App/Models/User')
const Picker = use('App/Models/Picker')
const OrderTime = use('App/Models/OrderTime')

const Event = use('Event')

const moment = use('moment');

const Database = use("Database");

const commonService = use('App/Services/CommonService')
const SelfHelpers = use('App/Services/SelfHelpers')


class MerchantController {

    async dashboard({ view, auth, response }) {
        const user_id = auth.user.id

        let current_week_orders = await Database.schema.raw(`select id as orders from orders where created_at between date_sub(now(), INTERVAL 1 WEEK) and date_sub(now(), INTERVAL 1 WEEK) and user_id = ${user_id}`)

        const categories = ["Current Week", "Current Week - 1", "Current Week - 2", "Current Week - 3"]
        return view.render("merchant.dashboard");
    }
    /*
    |--------------------------------------------------------------------------
    | Merchant Module - Protected ROUTES
    |--------------------------------------------------------------------------
    */
    async categories({ view, auth, response }) {
        const user_id = auth.user.id
        const menuCategory = await MenuCategory.query().where('user_id', user_id).where('is_deleted', 0).fetch()
        return view.render("merchant.categories.list", { menuCategory: menuCategory.toJSON() });
    }

    async addCategory({ view, auth, response }) {
        return view.render("merchant.categories.add");
    }

    async addCategorySubmit({ request, auth, response, session }) {
        try {
            const menu_data = request.only(["name"])
            menu_data.user_id = auth.user.id
            const cat = await MenuCategory.create(menu_data)
            session.flash({ type: 'success', message: 'Category added successfully' })
            return response.redirect('back')

        } catch (err) {
            session.flash({ type: 'danger', message: err.message })
            await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
            return response.redirect('back')
        }
    }

    async editCategory({ view, auth, response, session, params }) {

        const category = await MenuCategory.find(params.id)
        const user_id = auth.user.id

        if (!category || category.user_id != user_id) {
            session.flash({ type: 'danger', message: 'Item not found' })
            return response.redirect('back')
        }
        return view.render("merchant.categories.edit", { category: category.toJSON() });
    }

    async editCategorySubmit({ request, auth, response, session, params }) {
        try {
            const { name } = request.all()
            const category = await MenuCategory.find(params.id)
            const user_id = auth.user.id

            if (!category || category.user_id != user_id) {
                session.flash({ type: 'danger', message: 'Item not found' })
                return response.redirect('back')
            }
            category.name = name
            const cat = await category.save()
            session.flash({ type: 'success', message: 'Category updated successfully' })
            return response.redirect('back')

        } catch (err) {
            session.flash({ type: 'danger', message: err.message })
            await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
            return response.redirect('back')
        }
    }

    async deleteCategory({ view, auth, response, session, params }) {

        try {
            const category = await MenuCategory.find(params.id)
            const user_id = auth.user.id

            if (!category || category.user_id != user_id) {
                session.flash({ type: 'danger', message: 'Item not found' })
                return response.redirect('back')
            }
            category.is_deleted = 1
            const cat = await category.save()
            session.flash({ type: 'success', message: 'Category deleted successfully' })
            return response.redirect('back')

        } catch (err) {
            session.flash({ type: 'danger', message: err.message })
            await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
            return response.redirect('back')
        }
    }

    async activate({ view, auth, response, request, session }) {
        try {
            let is_activated = false
            const user_id = auth.user.id
            const data = await MerchantDetail.query().where('user_id', user_id).select('is_activated').fetch()
            if (data) {
                is_activated = data.toJSON()[0].is_activated
            }
            return view.render("merchant.activate", { is_activated });

        } catch (err) {
            session.flash({ type: 'danger', message: err.message })
            await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
            return response.redirect('back')
        }
    }

    async activateSubmit({ view, auth, response, request, session }) {
        try {
            const user_id = auth.user.id
            let data = await MerchantDetail.findBy('user_id', user_id)
            const message = data.is_activated ? "Store successfully deactivated" : "Store successfully activated"
            data.is_activated = !data.is_activated
            await data.save()
            session.flash({ type: 'success', message })
            return response.redirect('back', { is_activated: data.is_activated })

        } catch (err) {
            session.flash({ type: 'danger', message: err.message })
            await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
            return response.redirect('back')
        }
    }

    async bankAccount({ view, auth, response, request, session }) {
        try {
            const user_id = auth.user.id
            let data = await MerchantDetail.query().where('user_id', user_id).fetch()
            data = data.toJSON()[0]
            data.account_number = data.account_number.replace(/(?<=^\d{0,4})\d/g, '*')
            return view.render("merchant.bankAccount.bank-account", { data });

        } catch (err) {
            session.flash({ type: 'danger', message: err.message })
            await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
            return response.redirect('back')
        }
    }
    async bankAccountEdit({ view, auth, response, request, session }) {
        try {
            const user_id = auth.user.id
            let data = await MerchantDetail.query().select('bank_name', 'account_number', 'sort_code').where('user_id', user_id).fetch()
            data = data.toJSON()[0]
            return view.render("merchant.bankAccount.edit", { data });

        } catch (err) {
            session.flash({ type: 'danger', message: err.message })
            await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
            return response.redirect('back')
        }
    }
    async bankAccountEditSubmit({ view, auth, response, request, session }) {
        try {
            const data = request.only(['bank_name', 'account_number', 'sort_code'])
            const user_id = auth.user.id
            let result = await MerchantDetail.query().update(data).where('user_id', user_id)
            session.flash({ type: 'success', message: "Bank details updated successfully" })

            return response.redirect('/merchant/bank-account')
        } catch (err) {
            session.flash({ type: 'danger', message: err.message })
            await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
            return response.redirect('back')
        }
    }

    async menus({ view, auth, response, session }) {
        try {
            const user_id = auth.user.id
            const menus = await Menu.query().where('user_id', user_id).fetch()
            return view.render("merchant.menus.list", { menus: menus.toJSON() });
        } catch (err) {
            session.flash({ type: 'danger', message: err.message })
            await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
            return response.redirect('back')
        }
    }

    async addShow({ view, auth }) {
        const user_id = auth.user.id
        let all_categories = await MenuCategory.query().where('user_id', user_id).fetch()
        let categories = all_categories.toJSON()
        return view.render("merchant.menus.add", { categories });
    }

    //Adding Menu
    async add({ view, request, session, response, auth }) {
        try {
            const menu_data = request.only(["name", "description", "price", "category_id", "img_data"])
            //const image_uploaded = await SelfHelpers.uploadImage(request, "merchant/menu")
            menu_data.user_id = auth.user.id
            const img_data = menu_data.img_data

            if (SelfHelpers.isBase64(img_data)) {
                session.flash({ type: 'danger', message: "File validation failed!!" }).flashAll()
                return response.redirect('back')
            }
            menu_data.image = await SelfHelpers.uploadBase64Img(img_data, "merchant/menu")

            // menu_data.image = image_uploaded.file_name
            const menu = await Menu.create(menu_data)
            session.flash({ type: 'success', message: 'Menu added successfully' })
            return response.redirect('back')

        } catch (err) {
            session.flash({ type: 'danger', message: err.message })
            await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
            return response.redirect('back')
        }
    }

    async editShow({ view, session, response, params }) {
        try {

            let all_categories = await MenuCategory.all()
            let categories = all_categories.toJSON()

            const menu = await Menu.find(params.id)
            if (!menu) {
                session.flash({ type: 'danger', message: 'Item not found' })
                return response.redirect('back')
            }
            return view.render("merchant.menus.edit", { menu: menu.toJSON(), categories });
        } catch (err) {
            session.flash({ type: 'danger', message: err.message })
            await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
            return response.redirect('back')
        }
    }
    async edit({ view, session, request, response, params }) {
        try {

            const menu = await Menu.find(params.id)
            if (!menu) {
                session.flash({ type: 'danger', message: 'Item not found' })
                return response.redirect('back')
            }
            const { name, description, price, category_id } = request.body

            let image_uploaded = ""

            if (request.file('image')) {
                image_uploaded = await SelfHelpers.uploadImage(request, "merchant/menu")
            }

            if (request.file('image')) {
                if (!image_uploaded.is_uploaded) {
                    session.flash({ type: 'danger', message: image_uploaded.upload_response }).flashAll()
                    return response.redirect('back')
                }
            }

            if (request.file('image')) {
                menu.image = image_uploaded.file_name
            }
            menu.name = name
            menu.description = description
            menu.price = price
            menu.category_id = category_id

            await menu.save()
            session.flash({ type: 'success', message: 'Item updated successfully' })
            return response.redirect('/merchant/menus')
        } catch (err) {
            session.flash({ type: 'danger', message: err.message })
            await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
            return response.redirect('back')
        }
    }

    async businessHours({ view, auth, params }) {
        let user_id = auth.user.id
        const { merchant_id } = params
        // if logged in user is an admin
        if (typeof (merchant_id) !== 'undefined') {
            user_id = merchant_id
        }
        const business_hr = await MerchantBusinessHour.query().where('user_id', user_id).fetch()
        const business_hr_data = business_hr.toJSON()
        let days = await WeekDay.all()
        let days_data = days.toJSON()
        const hours = await Hour.all()
        const hours_data = hours.toJSON()
        const days_hours = days_data.map(element => ({
            ...element,
            hours: hours_data
        }));
        return view.render("merchant.businesshours.business-hours", { days: days_hours, business_hr_data });
    }

    async setBusinessHours({ request, auth, session, response }) {
        let user_id = auth.user.id
        const { merchant_id } = request.body
        // if logged in user is an admin
        if (merchant_id != 'merchant-business-hours') {
            user_id = merchant_id
        }

        const deleted = await MerchantBusinessHour.query().where('user_id', user_id).delete()
        let days = await WeekDay.all()
        let days_data = days.toJSON()
        const start_time = request.input('start_time')
        const end_time = request.input('end_time')
        let business_hours = []
        for (let i = 0; i < days_data.length; i++) {
            let record = {
                user_id,
                week_day_id: days_data[i].id,
                start_time: start_time[i],
                end_time: end_time[i],
                is_open: request.input(days_data[i].name) ? true : false
            }
            business_hours.push(record)
        }
        await MerchantBusinessHour.createMany(business_hours)
        await MerchantDetail.query().update({ is_business_hours: 1 }).where('user_id', user_id)

        session.flash({ type: 'success', message: 'Business hours added successfully' })
        return response.redirect('back')
    }
    async getOrders({ request, auth, session, response, view }) {
        let order_filter = 0
        let times = ""
        let order_screen = request.url()
        if (order_screen == "/merchant/orders/completed") {
            order_filter = 1
        }
        else
            if (order_screen == "/merchant/orders") {
                order_filter = 0
                times = await OrderTime.all()
                times = times.toJSON()
            }
        let user_id = auth.user.id
        let role_id = auth.user.role_id
        try {
            let query = Order.query().where('merchant_id', user_id).where('is_completed', order_filter).fetch()
            // If admin user, then fetch all orders
            if (role_id == 1) {
                query = Order.query().fetch()
            }
            let all_orders = await query
            let orders = all_orders.toJSON()
            return view.render("merchant.incomingOrders.list", { orders, times });
        } catch (err) {
            session.flash({ type: 'danger', message: err.message })
            await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
            return response.redirect('back')
        }
    }

    async updateOrderTime({ request, auth, session, response, view, params }) {
        let user_id = auth.user.id

        try {
            const { order_id, time_id } = params
            const order = await Order.find(order_id)
            if (!order || order.merchant_id != user_id) {
                session.flash({ type: 'danger', message: 'Order not found' })
                return response.redirect('back')
            }
            order.time_required = time_id
            await order.save()
            session.flash({ type: 'success', message: 'Order time updated successfully' })
            return response.redirect('back')

        } catch (err) {
            session.flash({ type: 'danger', message: err.message })
            await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
            return response.redirect('back')
        }
    }

    async viewOrder({ request, auth, session, response, view, params }) {
        let user_id = auth.user.id

        try {
            const order_id = params.order_id
            let all_orders = await OrderItem.query().with("menu").where('order_id', order_id).fetch()
            let orders = all_orders.toJSON()
            return view.render("merchant.incomingOrders.view-order", { orders });
        } catch (err) {
            session.flash({ type: 'danger', message: err.message })
            await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
            return response.redirect('back')
        }
    }
    async markOrderCompleted({ request, auth, session, response, view, params }) {
        let user_id = auth.user.id
        try {
            const order_id = params.order_id
            let all_orders = await OrderItem.query().with("menu").where('order_id', order_id).fetch()
            let orders = all_orders.toJSON()
            return view.render("merchant.incomingOrders.add-completed-details", { orders });
        } catch (err) {
            session.flash({ type: 'danger', message: err.message })
            await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
            return response.redirect('back')
        }
    }
    async markOrderSubmit({ request, auth, session, response, view, params }) {
        try {
            const order_id = params.order_id

            const order = await Order.find(order_id)
            if (!order) {
                session.flash({ type: 'danger', message: 'Item not found' })
                return response.redirect('back')
            }
            order.is_completed = 1
            await order.save()

            const picker_data = request.only(["name", "contact"])
            picker_data.order_id = order_id
            await Picker.create(picker_data)
            session.flash({ type: 'success', message: 'Order completed successfully' })
            return response.route('orders.completed.list')
        } catch (err) {
            session.flash({ type: 'danger', message: err.message })
            await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
            return response.redirect('back')
        }
    }

    async merchantEditShow({ view, session, response, params }) {
        try {
            const { id } = params
            let data = await User.query().with('merchantDetail', function (q) {
                q.where('user_id', id)
            }).where('id', id).fetch()
            data = data.toJSON()
            return view.render("admin.users.merchantEditShow", { data: data[0] });
        } catch (err) {
            session.flash({ type: 'danger', message: err.message })
            await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
            return response.redirect('back')
        }
    }




    async updateMerchantSubmit({ request, response, session, params }) {
        try {
            const { id } = request.params
            const user_data = request.only(["first_name", "last_name", "email", "mobile_number", "password"])
            let merchant_data = request.only(["restaurant_name", "restaurant_address", "business_type", "locations", "phone_number", "business_email", "menu_website", "delivery_available", "delivery_charges", "opening_hours", "legal_business_name", "vat_number", "legal_name", "date_of_birth", "bank_name", "sort_code", "account_number"])

            let image_uploaded = ""

            if (request.file('image')) {
                image_uploaded = await SelfHelpers.uploadImage(request, "merchant")
            }

            if (request.file('image')) {
                if (!image_uploaded.is_uploaded) {
                    session.flash({ type: 'danger', message: image_uploaded.upload_response }).flashAll()
                    return response.redirect('back')
                }
            }

            if (request.file('image')) {
                merchant_data.image = image_uploaded.file_name
            }

            const user = await User.query().where("id", id).update(user_data)
            const businessCustomer = await MerchantDetail.query().where("user_id", id).update(merchant_data)
            session.flash({ type: 'success', message: 'Profile details updated successfully' })
            return response.redirect('back')
        } catch (err) {
            session.flash({ type: 'danger', message: err.message })
            await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
            return response.redirect('back')
        }
    }

    async changeStatus({ request, response, session, params }) {
        try {
            const { action, id } = params

            const menu = await Menu.find(id)
            if (!menu) {
                session.flash({ type: 'danger', message: 'Item not found' })
                return response.redirect('back')
            }
            menu.is_deleted = action
            let action_txt = action == '0' ? "Item activated " : action == '1' ? "Item deleted " : "Item suspended "

            await menu.save()
            session.flash({ type: 'success', message: `${action_txt}successfully` })
            return response.redirect('back')
        } catch (err) {
            session.flash({ type: 'danger', message: err.message })
            await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
            return response.redirect('back')
        }
    }

    async finance({ response, session, view, auth }) {
        try {
            const user_id = auth.user.id

            const today = `${moment().format('YYYY-MM-DD')}%`
            let today_total = await Database.schema.raw(`select COALESCE(SUM(amount),0) as today_amount from orders where created_at LIKE '${today}' and merchant_id = ${user_id}`)

            let this_week = await Database.schema.raw(`select COALESCE(SUM(amount),0) as weekly_amount from orders where week(created_at)=week(now()) and merchant_id = ${user_id}`)
            let this_month = await Database.schema.raw(`SELECT COALESCE(SUM(amount),0) as monthly_amount FROM orders WHERE created_at between DATE_FORMAT(CURDATE() ,'%Y-%m-01') AND CURDATE() + INTERVAL 1 DAY and merchant_id = ${user_id}`)
            let this_year = await Database.schema.raw(`SELECT COALESCE(SUM(amount),0) as yearly_amount FROM orders WHERE created_at between DATE_FORMAT(CURDATE() ,'%Y-01-01') AND CURDATE() + INTERVAL 1 DAY and merchant_id = ${user_id}`)
            // let last_week = await Database.schema.raw(`select COALESCE(SUM(amount),0) as weekly_amount from orders where week(created_at)=week(now())-1 and merchant_id = ${user_id}`)
            // let last_month = await Database.schema.raw(`SELECT COALESCE(SUM(amount),0) as monthly_amount FROM orders WHERE YEAR(created_at) = YEAR(CURRENT_DATE - INTERVAL 1 MONTH) AND MONTH(created_at) = MONTH(CURRENT_DATE - INTERVAL 1 MONTH)  and user_id = ${user_id}`)
            // let last_year = await Database.schema.raw(`SELECT COALESCE(SUM(amount),0) as yearly_amount FROM orders WHERE YEAR(created_at) = YEAR(DATE_SUB(CURDATE(), INTERVAL 1 YEAR))`)

            const amount_result = {
                today_total: today_total[0][0].today_amount,
                weekly_amount: this_week[0][0].weekly_amount,
                monthly_amount: this_month[0][0].monthly_amount,
                yearly_amount: this_year[0][0].yearly_amount,
            }

            return view.render("merchant.finances", { amount_result });
        } catch (err) {
            session.flash({ type: 'danger', message: err.message })
            await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
            return response.redirect('back')
        }
    }

    async getFinance({ response, session, view, auth }) {
        try {
            // Last 7 days record
            // select id from orders where created_at between date_sub(now(), INTERVAL 1 WEEK) and now()
            const user_id = auth.user.id
            let categories = []
            let orders = []
            let this_month = await Database.schema.raw(`SELECT DATE_FORMAT(created_at, '%Y-%M-%d') as created_at, COALESCE(COUNT(id),0) as orders_count FROM orders WHERE created_at BETWEEN DATE_SUB( CURDATE( ) ,INTERVAL 10 DAY ) AND CURDATE( ) + INTERVAL 1 DAY group by DATE_FORMAT(created_at ,'%Y-%m-%d') order by created_at and merchant_id = ${user_id}`)
            // let this_month = await Database.schema.raw(`SELECT DATE_FORMAT(created_at, '%Y-%M-%d') as created_at, COALESCE(COUNT(id),0) as orders_count FROM orders WHERE created_at between DATE_FORMAT(CURDATE() ,'%Y-%m-01') AND CURDATE() group by DATE_FORMAT(created_at ,'%Y-%m-%d') order by created_at and merchant_id = ${user_id}`)
            this_month = this_month[0]
            let current_week_orders = await Database.schema.raw(`select COALESCE(COUNT(id),0) as orders from orders where week(created_at)=week(now()) and merchant_id = ${user_id}`)
            let last_week_orders = await Database.schema.raw(`select COALESCE(COUNT(id),0) as orders from orders where YEAR(created_at)=YEAR(now()) and week(created_at)=week(now())-1 and merchant_id = ${user_id}`)
            let second_last_week_orders = await Database.schema.raw(`select COALESCE(COUNT(id),0) as orders from orders where YEAR(created_at)=YEAR(now()) and week(created_at)=week(now())-2 and date_sub(now(), INTERVAL 2 WEEK) and merchant_id = ${user_id}`)
            let third_last_week_orders = await Database.schema.raw(`select COALESCE(COUNT(id),0) as orders from orders where  YEAR(created_at)=YEAR(now()) and week(created_at)=week(now())-3 and date_sub(now(), INTERVAL 3 WEEK) and merchant_id = ${user_id}`)

            const count = this_month.length
            for (let i = 0; i < count; i++) {
                categories.push(this_month[i].created_at)
                orders.push(this_month[i].orders_count)

            }
            // const categories = ["Current Week", "Current Week - 1", "Current Week - 2", "Current Week - 3"]
            // const orders = [
            //     current_week_orders[0][0].orders,
            //     last_week_orders[0][0].orders,
            //     second_last_week_orders[0][0].orders,
            //     third_last_week_orders[0][0].orders,
            // ]

            return response.json({ categories, orders })
        } catch (err) {
            session.flash({ type: 'danger', message: err.message })
            await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
            return response.redirect('back')
        }
    }

    async sendOrderEmail({ request, response }) {
        try {

            let data = {
                name: "user.first_name + ' ' + user.last_name",
                email: "sajjadramzan1211@gmail.com",
                link: "http://google.com"
            }
            //This Event will send Email to the user.
            await Event.fire('reset::password', data)

            return "this.successResponse('FORGOT_PASSWORD', user, response)";
        } catch (err) {
            return this.errorResponse(this.constructor.name, err.message, err.code, err, response);
        }
    }



}

module.exports = MerchantController
