"use strict";
const User = use('App/Models/User')
const BusinessCustomer = use('App/Models/BusinessCustomer')
const MerchantDetail = use('App/Models/MerchantDetail')
const MerchantBusinessHour = use('App/Models/MerchantBusinessHour')

const commonService = use('App/Services/CommonService')
const SelfHelpers = use('App/Services/SelfHelpers')

const Database = use("Database");
const Helpers = use('Helpers')
const public_path = Helpers.publicPath();

const validations = use('App/Services/Validation');



class AuthController {

  // GET
  // Show General login form
  async Login({ view, auth, response }) {

    try {
      if (await auth.check()) {
        const role_id = auth.user.role_id
        const return_to = SelfHelpers.getRetunrRoute(role_id)

        return response.redirect(return_to);

      }
    } catch (err) {
      return view.render("auth.customer-login");
    }

  }
  // POST
  // Validate customer login form
  async LoginSubmit({ auth, request, response, session, view }) {
    try {
      const { email, password, returnURL } = request.all()

      let user = await auth.attempt(email, password)
      const is_active = user.is_active
      if (!is_active) {
        session.flash({ type: 'danger', message: "User blocked or deleted by admin" }).flashAll()
        await auth.logout()
        return response.redirect('back')
      }

      const role_id = user.role_id
      if (role_id == 2) {

      }
      //Getting return to route
      let return_to = SelfHelpers.getRetunrRoute(role_id)
      if (returnURL == 'cart') {
        return_to = '/my/cart'
      }
      if (returnURL == 'reorder') {
        return_to = '/re-order'
      }
      return response.redirect(return_to)
    } catch (err) {
      console.log(err.message)
      let message = "Something went wrong"
      const error_message = err.message
      if (error_message.includes('E_PASSWORD_MISMATCH:')) {
        message = 'Invalid credentials'
      }
      if (error_message.includes('E_USER_NOT_FOUND:')) {
        message = 'User does not exist'
      }
      session.flash({ type: 'danger', message }).flashAll()
      await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
      return response.redirect('back')
    }

  }
  // GET
  async customerRegister({ view }) {
    return view.render("auth.customer-register");
  }

  // POST
  // Register Customer
  async customerRegisterSubmit({ request, response, session }) {
    try {
      const data = request.only(["first_name", "last_name", "email", "mobile_number", "password"])
      data.role_id = 4
      const user = await User.create(data)

      session.flash({ type: 'success', message: 'User created successfully' })
      return response.redirect('back')
    } catch (err) {
      session.flash({ type: 'danger', message: err.message })
      await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
      return response.redirect('back')
    }
  }

  /*
  |--------------------------------------------------------------------------
  | Business Customer Register - ROUTES
  |--------------------------------------------------------------------------
  */
  async businessCustomerRegister({ view }) {
    return view.render("auth.business-customer-register");
  }

  async businessCustomerRegisterSubmit({ request, response, session }) {
    try {
      const user_data = request.only(["first_name", "last_name", "email", "mobile_number", "password"])
      const user_business_data = request.only(["user_name", "business_owner", "business_name", "business_website", "phone_number", "business_address", "country", "city", "post_code", "street_address_1", "street_address_1"])

      user_data.role_id = 3
      const user = await User.create(user_data)
      user_business_data.user_id = user.id

      const businessCustomer = await BusinessCustomer.create(user_business_data)
      session.flash({ type: 'success', message: 'User created successfully' })
      return response.redirect('back')
    } catch (err) {
      session.flash({ type: 'danger', message: err.message })
      await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
      return response.redirect('back')
    }
  }

  async logout({ auth, response, session }) {
    try {
      await auth.logout()
      return response.redirect('/')
    } catch (err) {
      await auth.logout()
      session.flash({ type: 'danger', message: err.message })
      await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
      return response.redirect('back')
    }

  }
  /*
  |--------------------------------------------------------------------------
  | Merchant - Sign Up
  |--------------------------------------------------------------------------
  */

  async merchantBasic({ view, session, request }) {
    // Getting basic info from session
    const ip = request.ip()

    let data = SelfHelpers.getFormData(session, 'basic_data')
    return view.render("auth.merchant-basic", { data, ip });
  }

  // Basic Merchant Submit
  async merchantBasicSubmit({ view, request, response, session }) {
    const basic_data = request.only(["restaurant_name", "restaurant_address", "restaurant_lat", "zip_code", "restaurant_lng", "email", "mobile_number", "password"])
    console.log(basic_data)
    session.put('merchant_data', basic_data)
    session.put('basic_data', basic_data)
    return response.redirect('/merchant/details/1')
  }

  async merchantDetailsForm1({ view, session, request }) {
    // Getting basic info from session
    let data = SelfHelpers.getFormData(session, 'business_data')
    return view.render("auth.merchant-details-form-1", data);
  }

  async merchantDetailsForm1Submit({ request, response, session }) {
    try {

      const business_data = request.only(["business_type", "locations", "first_name", "last_name", "phone_number", "business_email"])
      const basic_data = session.get('merchant_data')
      const merged_data = { ...basic_data, ...business_data }
      let isValid = await validations.validates(merged_data, 'merchantDetailsForm1');
      if (isValid.length > 0) {
        session.flash({ type: 'danger', message: isValid[0].message }).flashAll()
        return response.redirect('back')
      }

      session.put('merchant_data', merged_data)
      session.put('business_data', business_data)
      return response.redirect('/merchant/details/2')

    } catch (err) {
      session.flash({ type: 'danger', message: err.message })
      await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
      return response.redirect('back')
    }
  }

  async merchantDetailsForm2({ view, request, response, session }) {
    // Getting basic info from session
    let data = SelfHelpers.getFormData(session, 'promote_data')
    return view.render("auth.merchant-details-form-2", data);
  }

  async merchantDetailsForm2Submit({ view, request, response, session }) {
    try {
      const promote_data = request.only(["menu_website", "delivery_available", "delivery_charges", "opening_hours"])
      const prev_data = session.get('merchant_data')
      if (!request.file('image')) {
        session.flash({ type: 'danger', message: "Kindly provide menu file" }).flashAll()
        return response.redirect('back')
      }
      const image_uploaded = await SelfHelpers.uploadImage(request, "merchant")
      if (!image_uploaded.is_uploaded) {
        session.flash({ type: 'danger', message: image_uploaded.upload_response }).flashAll()
        return response.redirect('back')
      }
      promote_data.image = image_uploaded.file_name
      const merged_data = { ...prev_data, ...promote_data }
      let isValid = await validations.validates(merged_data, 'merchantDetailsForm2');
      if (isValid.length > 0) {
        session.flash({ type: 'danger', message: isValid[0].message }).flashAll()
        return response.redirect('back')
      }
      session.put('merchant_data', merged_data)
      session.put('promote_data', promote_data)
      return response.redirect('/merchant/details/3')

    } catch (err) {
      session.flash({ type: 'danger', message: err.message })
      await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
      return response.redirect('back')
    }

  }

  async merchantDetailsForm3({ view }) {
    return view.render("auth.merchant-details-form-3");
  }


  async merchantDetailsForm4({ view }) {
    return view.render("auth.merchant-details-form-4");
  }

  async register({ view, request, response, session, auth }) {
    const trx = await Database.beginTransaction();
    try {
      const bank_account_data = request.only(["legal_business_name", "vat_number", "legal_name", "date_of_birth", "bank_name", "sort_code", "account_number"])
      const prev_data = session.get('merchant_data')
      const merged_data = { ...prev_data, ...bank_account_data }
      let isValid = await validations.validates(merged_data, 'merchantDetailsForm4');
      if (isValid.length > 0) {
        session.flash({ type: 'danger', message: isValid[0].message }).flashAll()
        return response.redirect('back')
      }
      session.put('merchant_data', merged_data)
      const all_data = session.get('merchant_data')
      // Inserting User Data
      const user_data = {
        first_name: all_data.first_name,
        last_name: all_data.last_name,
        email: all_data.email,
        mobile_number: all_data.mobile_number,
        password: all_data.password,
        role_id: 2
      }
      const user = await User.create(user_data, trx)
      const user_id = user.id

      const merchant_detail = {
        user_id,
        restaurant_name: all_data.restaurant_name,
        restaurant_address: all_data.restaurant_address,
        zip_code: all_data.zip_code,
        restaurant_lat: all_data.restaurant_lat,
        restaurant_lng: all_data.restaurant_lng,
        business_type: all_data.business_type,
        locations: all_data.locations,
        phone_number: all_data.phone_number,
        business_email: all_data.business_email,
        menu_website: all_data.menu_website,
        image: all_data.image,
        delivery_available: all_data.delivery_available,
        delivery_charges: all_data.delivery_charges,
        opening_hours: all_data.opening_hours,
        legal_business_name: all_data.legal_business_name,
        vat_number: all_data.vat_number,
        legal_name: all_data.legal_name,
        date_of_birth: all_data.date_of_birth,
        bank_name: all_data.bank_name,
        sort_code: all_data.sort_code,
        account_number: all_data.account_number,
      }

      const merchant = await MerchantDetail.create(merchant_detail, trx)
      session.clear()
      await trx.commit();
      let login_user = await auth.attempt(all_data.email, all_data.password)

      return view.render("auth.merchant-message");
    } catch (err) {
      trx.rollback();
      session.flash({ type: 'danger', message: err.message })
      await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
      return response.redirect('back')
    }
  }

  // Merchant Sign Up End

  async message({ view }) {
    return view.render("auth.business-customer");
  }


  async success({ auth, view }) {
    //MerchantBusinessHour
    // let user_id = auth.user.id
    // let defaultBusinessHours = [
    //   { user_id, week_day_id: 1, start_time: '12 AM', end_time: '12 AM', is_open: 1 },
    //   { user_id, week_day_id: 2, start_time: '12 AM', end_time: '12 AM', is_open: 1 },
    //   { user_id, week_day_id: 3, start_time: '12 AM', end_time: '12 AM', is_open: 1 },
    //   { user_id, week_day_id: 4, start_time: '12 AM', end_time: '12 AM', is_open: 1 },
    //   { user_id, week_day_id: 5, start_time: '12 AM', end_time: '12 AM', is_open: 1 },
    //   { user_id, week_day_id: 6, start_time: '12 AM', end_time: '12 AM', is_open: 1 },
    //   { user_id, week_day_id: 7, start_time: '12 AM', end_time: '12 AM', is_open: 1 },
    // ]

    // await MerchantBusinessHour.createMany(defaultBusinessHours)
    return view.render("auth.success");
  }


}

module.exports = AuthController;
