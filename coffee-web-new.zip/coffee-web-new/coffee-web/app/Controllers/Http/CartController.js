'use strict'

const Cart = use('App/Services/Cart')
const commonService = use('App/Services/CommonService')
const Order = use('App/Models/Order')
const OrderItem = use('App/Models/OrderItem')
const MerchantDetail = use('App/Models/MerchantDetail')
const Env = use("Env");
const baseUrl = Env.get("APP_URL");
const SECRET_KEY = Env.get("SECRET_KEY");

const stripe = require('stripe')(SECRET_KEY)

class CartController {
    async addToCart({ view, request, response, session, params }) {

        try {
            const id = params.id
            const merchant_id = params.merchant_id

            const qty = 1
            let cart = (session.get('cart')) && session.get('cart') != "Empty" ? session.get('cart') : null;
            let cart_items = await Cart.addToCart(merchant_id, id, qty, cart);

            session.put('cart', cart_items)
            const restaurant_found = { cart_items }
            return response.json(restaurant_found)


        } catch (err) {
            session.flash({ type: 'danger', message: err.message })
            await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
            return response.redirect('/')
        }

    }

    async removeFromCart({ view, request, response, session, params }) {

        try {
            const id = params.id

            let cart = (session.get('cart')) && session.get('cart') != "Empty" ? session.get('cart') : null;
            let cart_items = await Cart.removeFromCart(id, cart);
            return response.json({ cart_items })

        } catch (err) {
            session.flash({ type: 'danger', message: err.message })
            await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
            return response.redirect('/')
        }

    }
    async updateCart({ view, request, response, session, params }) {

        try {

            let { ids, qtys } = request.get()
            ids = ids.split(',')
            qtys = qtys.split(',')

            let cart = (session.get('cart')) && session.get('cart') != "Empty" ? session.get('cart') : null;
            let cart_items = await Cart.updateCart(ids, qtys, cart);
            return response.json({ cart_items })

        } catch (err) {
            session.flash({ type: 'danger', message: err.message })
            await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
            return response.redirect('/')
        }

    }

    async createCheckouSession({ view, request, response, session, params }) {
        try {
            const line_items_data = await this.arrangeData(session)
            const stripe_session = await stripe.checkout.sessions.create({
                payment_method_types: ['card'],
                line_items: line_items_data,
                mode: 'payment',
                success_url: `${baseUrl}/payment-success?id={CHECKOUT_SESSION_ID}`,
                cancel_url: `${baseUrl}/payment-cancel`,
            });

            response.json({ id: stripe_session.id });
        } catch (err) {
            session.flash({ type: 'danger', message: err.message })
            await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
            return response.redirect('/')
        }

    }

    async paymentSuccess({ view, response, session, auth, request }) {
        try {

            const { id } = request.get()
            const cutlery_info = session.get('cutlery_info') ? session.get('cutlery_info') : null
            const stripe_session = await stripe.checkout.sessions.retrieve(id, { expand: ['line_items'] })
            const delivery_address = session.get('address')
            const cart = session.get('cart')
            const user_id = auth.user.id
            const order_data = {
                delivery_address,
                cutlery_info,
                user_id,
                stripe_session: JSON.stringify(stripe_session),
                merchant_id: cart.items[0].merchant_id,
                amount: cart.items.totals
            }

            const order = await Order.create(order_data)
            const order_id = order.id
            const items = cart.items.map(item => {
                let obj = {
                    order_id,
                    product_id: item.id,
                    'name': item.name,
                    'quantity': item.qty,
                }
                return obj
            })
            const items_created = OrderItem.createMany(items)
            session.put('cart', "Empty");
            session.put('cutlery_info', null);

            console.log('\x1b[36m%s\x1b[0m', " ***** *****************************************************************")
            console.log(order_id)
            console.log('\x1b[36m%s\x1b[0m', " ***** *****************************************************************")


            let created_order = await Order.query().where('id', order_id).with('order_items', function (q) {
                q.with('menu')
            }).fetch()
            created_order = created_order.toJSON()

            const merchant_id = created_order[0].merchant_id
            let merchant = await MerchantDetail.query().where('user_id', merchant_id).select('restaurant_name', 'restaurant_lat', 'restaurant_lng').first()
            const merchant_latlang = merchant.toJSON()

            return view.render("home.paymentSuccess", { created_order: created_order[0], latlang: merchant_latlang });

        } catch (err) {
            session.flash({ type: 'danger', message: err.message })
            await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
            return response.redirect('/')
        }
    }
    async paymentCancel({ view, request, response, session, params }) {

        try {
            const data = {
                "Payment": "paymentCancel"
            }
            return response.json(data)

        } catch (err) {
            session.flash({ type: 'danger', message: err.message })
            await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
            return response.redirect('/')
        }

    }

    async arrangeData(session) {
        const cart = session.get('cart')
        const items = cart.items.map(item => {
            let obj = {}
            let price_data = {}
            price_data.currency = 'gbp'
            price_data.product_data = { 'name': item.name }
            price_data.unit_amount = parseInt(item.price) * 100
            obj.price_data = price_data
            obj.quantity = item.qty
            return obj
        })
        return items
    }

    async checkSession({ view, request, response, session, params }) {

        try {
            const data = await this.arrangeData(session)
            return response.json(data)

        } catch (err) {
            session.flash({ type: 'danger', message: err.message })
            await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
            return response.redirect('/')
        }

    }

    async addCultery({ view, request, response, session, params }) {

        try {
            const { info } = request.get()
            const data = { info }
            session.put('cutlery_info', info)
            return response.json(data)
        } catch (err) {
            session.flash({ type: 'danger', message: err.message })
            await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
            return response.redirect('/')
        }
    }


    async reOrder({ view, params, response, session, request, auth }) {

        try {
            const user_id = auth.user.id;

            let prev_orders = await Order.query().where('user_id', user_id).with('order_items', function (q) {
                q.with('menu')
            }).select('id', 'user_id', 'cutlery_info', 'delivery_address', 'amount').fetch()
            prev_orders = prev_orders.toJSON()
            return view.render("home.re-order", { prev_orders });
        } catch (err) {
            session.flash({ type: 'danger', message: err.message })
            await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
            return response.redirect('/')
        }
    }

    async placeReOrder({ view, params, response, session, request, auth }) {
        const user_id = auth.user.id;
        const { order_id } = request.params
        let selected_order = await Order.query().where('id', order_id).with('order_items').select('id', 'user_id', 'cutlery_info', 'delivery_address', 'merchant_id').fetch()
        selected_order = selected_order.toJSON()

        for (let i = 0; i < selected_order.length; i++) {
            let order_items = selected_order[i].order_items
            for (let j = 0; j < order_items.length; j++) {
                let merchant_id = selected_order[i].merchant_id
                let id = order_items[j].product_id
                let qty = order_items[j].quantity

                let cart = (session.get('cart')) && session.get('cart') != "Empty" ? session.get('cart') : null;
                let cart_items = await Cart.addToCart(merchant_id, id, qty, cart);
                session.put('cart', cart_items)
            }
        }
        response.route('myCart')
    }

}

module.exports = CartController
