"use strict";

const Env = use("Env");
const IP_API_KEY = Env.get("IP_API_KEY");

class HomeController {
  async index({ view, request }) {
    const ip = request.ip()
    return view.render("home.index", { IP_API_KEY, ip });
  }
  async endUserLicense({ view }) {
    return view.render("home.end-user-license");
  }

  async consumerFaq({ view }) {
    return view.render("home.consumer-faq");
  }

  async referral({ view }) {
    return view.render("home.referral");
  }

  async healthSafety({ view }) {
    return view.render("home.health-safety");
  }

  async privacy({ view }) {
    return view.render("home.privacy");
  }

  async termsAndConditions({ view }) {
    return view.render("home.terms-and-conditions");
  }

  async AboutUs({ view }) {
    return view.render("home.about-us");
  }

  async contactUs({ view }) {
    return view.render("home.contact-us");
  }

  async business({ view }) {
    return view.render("home.business");
  }
  async groupOrder({ view }) {
    return view.render("home.group-order");
  }
  async restaurants({ view }) {
    return view.render("home.restaurants");
  }

  async protected({ view }) {
    return "We in protected. . .";
  }
  async notFound({ view }) {
    return view.render("home.notFound");
  }
}

module.exports = HomeController;
