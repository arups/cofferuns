'use strict'
const Database = use("Database");
const SpreadSheet = use('SpreadSheet')

const User = use('App/Models/User')
const Menu = use('App/Models/Menu')
const MerchantDetail = use('App/Models/MerchantDetail')
const Order = use('App/Models/Order')
const OrderItem = use('App/Models/OrderItem')

const Hour = use('App/Models/Hour')
const WeekDay = use('App/Models/WeekDay')
const MerchantBusinessHour = use('App/Models/MerchantBusinessHour')


const commonService = use('App/Services/CommonService')
const Env = use("Env");

const PUBLISH_KEY = Env.get("PUBLISH_KEY");

class RetailCustomerController {
    async search({ view, auth, response, session, request, params }) {
        try {
            let query = ""
            let Restaurants_HTML = "EMPTY . . . "
            let data = []
            let restaurants_data = []
            let final_restaurants_data = []
            let day_data = []
            const { lat, lng, address, zipcode } = request.get()

            session.put('address', address || zipcode)
            let location = ''
            if (lat && lng) {
                query = `SELECT restaurant_lat, restaurant_lng, restaurant_name, id, user_id,  zip_code, restaurant_address, image,  (6373 * ACOS(COS(RADIANS(${lat})) * COS(RADIANS(restaurant_lat)) * COS(RADIANS(restaurant_lng) - RADIANS(${lng})) + SIN(RADIANS(${lat})) * SIN(RADIANS(restaurant_lat)))) AS distance FROM merchant_details WHERE is_activated = 1  AND is_business_hours = 1 HAVING distance < 4.5`
                location = { lat, lng, is_location: "location" }
            }
            if (zipcode) {
                query = `SELECT restaurant_lat, restaurant_lng, id, user_id, restaurant_name, restaurant_address, image, zip_code FROM merchant_details WHERE zip_code = '${zipcode}' AND  WHERE is_activated = 1 AND WHERE is_business_hours = 1`
                location = {}
            }
            if (query != "") {
                const results = await Database.raw(query)
                const restaurants = results[0]
                restaurants_data = restaurants
                data = restaurants.map(rest => Object.values(rest))
                // if (!zipcode) {
                //     data.push(Object.values(location))
                // }
            }
            if (restaurants_data.length > 0) {
                // Get opening hours
                let user_ids = restaurants_data.map(item => item.user_id)
                const current_day = new Date().getDay() + 1;
                let day = await MerchantBusinessHour.query().with('weekday').where('week_day_id', current_day).whereIn('user_id', user_ids).fetch()
                day_data = day.toJSON()

                let day_associated = {}
                for (let i = 0; i < day_data.length; i++) {
                    day_associated[day_data[i].user_id] = {
                        is_open: day_data[i].is_open,
                        start_time: day_data[i].start_time,
                        end_time: day_data[i].end_time,
                    };
                }
                final_restaurants_data = restaurants_data.map(item => {
                    item.day_data = day_associated[item.user_id]
                    return item
                })

                // Generating Restaurants HTML
            }
            else {
                Restaurants_HTML = `
                <div class='px-3 py-3'>
                <div class="alert alert-warning" role="alert">
                    Restaurants Not Found
                </div>
              </div>`
            }
            const restaurant_found = { data, Restaurants_HTML, final_restaurants_data }
            return response.json(restaurant_found)
        } catch (err) {
            session.flash({ type: 'danger', message: err.message })
            await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
            return response.redirect('back')
        }
    }

    async restaurantMenu({ view, params, response, session, request }) {
        const { id } = params
        const data = await MerchantDetail.query().where('user_id', id).select('restaurant_name', 'restaurant_address', 'phone_number', 'business_email', 'menu_website', 'delivery_charges', 'delivery_available').first()

        const menus = await Menu.query().where('user_id', id).fetch()
        return view.render("home.restaurant-menu", { menus: menus.toJSON(), restraunt_details: data.toJSON() });
    }

    async myCart({ view, params, response, session, request }) {
        const cart = session.get('cart')
        const cutlery_info = session.get('cutlery_info')
        return view.render("home.cart-list", { cart, cutlery_info, key: PUBLISH_KEY });
    }
}

module.exports = RetailCustomerController
