'use strict'
const User = use('App/Models/User')
const BusinessCustomer = use('App/Models/BusinessCustomer')
const MerchantDetail = use('App/Models/MerchantDetail')
const commonService = use('App/Services/CommonService')
const SelfHelpers = use('App/Services/SelfHelpers')

class AdminController {
    async getUsers(role_id) {
        const users = await User.query().with('role', function (q) {
            q.select('id', 'name')
        }).where('role_id', role_id).fetch()
        return users.toJSON()
    }

    async getBusinessCustomer(role_id, id) {
        const data = await User.query().with('businessCustomer', function (q) {
            q.where('user_id', id)
        }).where('role_id', role_id).where('id', id).fetch()
        return data.toJSON()
    }
    async getMerchant(role_id, id) {
        const data = await User.query().with('merchantDetail', function (q) {
            q.where('user_id', id)
        }).where('role_id', role_id).where('id', id).fetch()
        return data.toJSON()
    }

    async merchantList({ view, auth, response }) {
        try {
            const users = await this.getUsers(2)
            const heading = "Merchants"
            return view.render("admin.users.list", { users, heading });
        } catch (err) {
            console.log("Err", err);
            return view.render("auth.customer-login");
        }
    }
    async businessCustomerList({ view, auth, response }) {
        try {
            const heading = "Business Customer"

            const users = await this.getUsers(3)
            return view.render("admin.users.list", { users, heading });
        } catch (err) {
            console.log("Err", err);
            return view.render("auth.customer-login");
        }
    }
    async retailCustomerList({ view, auth, response }) {
        try {
            const heading = "Customers"
            const users = await this.getUsers(4)
            return view.render("admin.users.list", { users, heading });
        } catch (err) {
            console.log("Err", err);
            return view.render("auth.customer-login");
        }
    }

    async userDetails({ view, auth, response, params }) {
        try {
            const { role_id, id } = params
            let data = ""
            let viewName = ""
            let heading = ""
            if (role_id == 2) {
                viewName = "merchantDetails"
                heading = "Merchant Details"
                data = await this.getMerchant(role_id, id)
            }
            else
                if (role_id == 3) {
                    viewName = "businessCustomerDetails"
                    heading = "Business Customer Details"
                    data = await this.getBusinessCustomer(role_id, id)
                }
                else
                    if (role_id == 4) {
                        return "Customer"
                    }
            return view.render(`admin.users.${viewName}`, { data, heading });
        } catch (err) {
            console.log("Err", err);
            return view.render("auth.customer-login");
        }
    }
    async businessCustomerEditShow({ view, session, response, params }) {
        try {
            const { role_id, id } = params
            const data = await this.getBusinessCustomer(role_id, id)
            return view.render("admin.users.businessCustomerEditShow", { data: data[0] });
        } catch (err) {
            session.flash({ type: 'danger', message: err.message })
            await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
            return response.redirect('back')
        }
    }


    async updateBusinessCustomerSubmit({ request, response, session, params }) {
        try {
            const { id } = request.params
            const user_data = request.only(["first_name", "last_name", "email", "mobile_number", "password"])
            const user_business_data = request.only(["user_name", "business_owner", "business_name", "business_website", "phone_number", "business_address", "country", "city", "post_code", "street_address_1", "street_address_1"])
            const user = await User.query().where("id", id).update(user_data)
            const businessCustomer = await BusinessCustomer.query().where("user_id", id).update(user_business_data)
            session.flash({ type: 'success', message: 'User updated successfully' })
            return response.redirect('back')
        } catch (err) {
            session.flash({ type: 'danger', message: err.message })
            await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
            return response.redirect('back')
        }
    }

    async merchantEditShow({ view, session, response, params }) {
        try {
            const { role_id, id } = params
            const data = await this.getMerchant(role_id, id)

            return view.render("admin.users.merchantEditShow", { data: data[0] });
        } catch (err) {
            session.flash({ type: 'danger', message: err.message })
            await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
            return response.redirect('back')
        }
    }


    async updateMerchantSubmit({ request, response, session, params }) {
        try {


            const { id } = request.params
            const user_data = request.only(["first_name", "last_name", "email", "mobile_number", "password"])
            let merchant_data = request.only(["restaurant_name", "restaurant_address", "business_type", "locations", "phone_number", "business_email", "menu_website", "delivery_available", "delivery_charges", "opening_hours", "legal_business_name", "vat_number", "legal_name", "date_of_birth", "bank_name", "sort_code", "account_number"])

            let image_uploaded = ""

            if (request.file('image')) {
                image_uploaded = await SelfHelpers.uploadImage(request, "merchant")
            }

            if (request.file('image')) {
                if (!image_uploaded.is_uploaded) {
                    session.flash({ type: 'danger', message: image_uploaded.upload_response }).flashAll()
                    return response.redirect('back')
                }
            }

            if (request.file('image')) {
                merchant_data.image = image_uploaded.file_name
                console.log(merchant_data.image)
            }

            const user = await User.query().where("id", id).update(user_data)
            const businessCustomer = await MerchantDetail.query().where("user_id", id).update(merchant_data)




            session.flash({ type: 'success', message: 'User updated successfully' })
            return response.redirect('back')
        } catch (err) {
            session.flash({ type: 'danger', message: err.message })
            await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
            return response.redirect('back')
        }
    }

    async blockUser({ view, request, response }) {
        try {
            const { user_id } = request.body
            let user = await User.find(user_id)
            user.is_active = !user.is_active
            await user.save()
            return response.redirect('/admin/users')
        } catch (err) {
            session.flash({ type: 'danger', message: err.message })
            await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
            return response.redirect('back')
        }
    }

}

module.exports = AdminController
