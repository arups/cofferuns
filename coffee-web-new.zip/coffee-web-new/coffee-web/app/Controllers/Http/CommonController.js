'use strict'

const User = use('App/Models/User')
const commonService = use('App/Services/CommonService')
const Hash = use('Hash')


class CommonController {
    async index({ view, auth, response, session }) {
        try {
            const user = await auth.getUser();

            return view.render("retial-customer.profile.list", { user: user.toJSON() });
        } catch (err) {
            session.flash({ type: 'danger', message: err.message })
            await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
            return response.redirect('back')
        }
    }

    async editShow({ view, auth, response, session }) {
        try {
            let user = await auth.getUser();
            return view.render("retial-customer.profile.edit", { user: user.toJSON() });
        } catch (err) {
            session.flash({ type: 'danger', message: err.message })
            await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
            return response.redirect('back')
        }
    }

    async edit({ view, auth, request, response, session }) {
        try {
            const updated_data = request.only(['first_name', 'last_name', 'mobile_number']);
            let user = await auth.getUser();
            user.first_name = updated_data.first_name
            user.last_name = updated_data.last_name
            user.mobile_number = updated_data.mobile_number
            await user.save()
            session.flash({ type: 'success', message: 'Profile updated successfully' })
            return response.redirect('back')
        } catch (err) {
            session.flash({ type: 'danger', message: err.message })
            await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
            return response.redirect('back')
        }
    }

    async changePassewordShow({ view, auth, response, session }) {
        try {
            let user = await auth.getUser();
            return view.render("retial-customer.profile.change-password", { user: user.toJSON() });
        } catch (err) {
            session.flash({ type: 'danger', message: err.message })
            await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
            return response.redirect('back')
        }
    }
    async changePasseword({ request, auth, response, session }) {
        try {
            const data = request.only(['password', 'old_password']);
            const user = auth.current.user
            const verifyPassword = await Hash.verify(
                data.old_password,
                user.password
            )

            if (!verifyPassword) {
                session.flash({ type: 'danger', message: 'Old password is not correct' }).flashAll()
                return response.redirect('back')
            }
            user.password = data.password
            await user.save()
            session.flash({ type: 'success', message: 'Password updated successfully' })
            return response.redirect('/customer')
        } catch (err) {
            session.flash({ type: 'danger', message: err.message })
            await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
            return response.redirect('back')
        }
    }

}

module.exports = CommonController
