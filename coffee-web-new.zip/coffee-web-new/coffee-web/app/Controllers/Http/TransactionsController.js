"use strict";
const Order = use('App/Models/Order')
const commonService = use('App/Services/CommonService')
const SelfHelpers = use('App/Services/SelfHelpers')
const SpreadSheet = use('SpreadSheet')

class TransactionsController {
  async index({ view, session, response }) {

    try {
      let transaction_data = await this.getTransactionData()
      return view.render("admin.transactions.list", { transaction_data });
    } catch (err) {
      session.flash({ type: 'danger', message: err.message })
      await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
      return response.redirect('back')
    }
  }
  async download({ view, session, response, params }) {

    try {
      let transaction_data = await this.getTransactionData()


      const ss = new SpreadSheet(response, params.format)
      const data = []

      data.push([
        'S. No.',
        'Payment ID',
        'Customer Email',
        'Amount(£)',
        'Status'
      ])
      const trx_length = transaction_data.length
      for (let i = 0; i < trx_length; i++) {
        let s_no = i + 1
        data.push([
          s_no,
          transaction_data[i].payment_intent,
          transaction_data[i].email,
          transaction_data[i].amount_total,
          transaction_data[i].payment_status,
        ])

      }

      ss.addSheet('Transactions', data)
      ss.download('Transactions')
    } catch (err) {
      session.flash({ type: 'danger', message: err.message })
      await commonService.consoleError(this.constructor.name, new Error(), err.message, err)
      return response.redirect('back')
    }
  }

  async getTransactionData() {

    let transaction_data = []
    let all_orders = await Order.query().fetch()
    let orders = await all_orders.toJSON()
    const order_length = orders.length

    for (let i = 0; i < order_length; i++) {
      const transaction = JSON.parse(orders[i].stripe_session)
      const amount_total = transaction.amount_total / 100
      const payment_status = SelfHelpers.capitalizeFirstLetter(transaction.payment_status)
      const payment_intent = transaction.payment_intent


      transaction_data.push({
        email: transaction.customer_details.email,
        amount_total,
        payment_status,
        payment_intent,
        created_at: orders[i].created_at
      })

      return transaction_data

    }


  }


}

module.exports = TransactionsController;
