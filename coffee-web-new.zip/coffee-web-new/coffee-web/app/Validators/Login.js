'use strict'
const { formatters } = use('Validator')

class Login {
  get validateAll () {
    return true
  }

 
  get rules() {
    return {
      email: 'required|email',
      password: 'required|number',
    }
  }

  get messages() {
    return {
      'required': '{{ field }} is required',
      'email': '{{ field }} must be a valid email',

    }
  }

  get formatter() {
    return formatters.JsonApi
  }

  async fails(errorMessages) {
    this.ctx.session.flash({ type: 'danger', message: errorMessages.errors[0].detail }).flashAll()
        return this.ctx.response.redirect('back')
  }
}

module.exports = Login
