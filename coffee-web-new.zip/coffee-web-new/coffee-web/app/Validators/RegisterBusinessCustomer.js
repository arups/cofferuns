'use strict'
const { formatters } = use('Validator')

class RegisterBusinessCustomer {
  get validateAll() {
    return true
  }


  get rules() {
    const custome_rules = {
      first_name: 'required|min:3|max:30',
      last_name: 'required|min:3|max:30',
      email: 'required|email|unique:users,email',
      mobile_number: 'required',
      password: 'required|min:3|max:16',
      user_name: 'required|min:3|max:100',
      business_owner: 'required|min:3|max:100',
      business_name: 'required|min:3|max:100',
      business_website: 'required|min:3|max:255',
      phone_number: 'required|min:3|max:30',
      business_address: 'required|min:3|max:255',
      country: 'required|min:3|max:100',
      city: 'required|min:3|max:100',
      post_code: 'required|min:3|max:20',
      street_address_1: 'required|min:3|max:255',
      street_address_2: 'required|min:3|max:255'
    }

    if (this.ctx.request.url().includes('edit')) {
      delete custome_rules.email
      delete custome_rules.password
    }
    return custome_rules
  }

  get messages() {
    return {
      'required': '{{ field }} is required',
      'max': 'Maximum length allowed for {{ field }} is {{ argument.0 }}',
      'min': '{{ field }} must contain at least {{ argument.0 }} characters',
      'email': '{{ field }} must be a valid email',
      'email.unique': '{{ field }} already registered',

    }
  }

  get formatter() {
    return formatters.JsonApi
  }

  async fails(errorMessages) {
    this.ctx.session.flash({ type: 'danger', message: errorMessages.errors[0].detail }).flashAll()
    return this.ctx.response.redirect('back')
  }
}

module.exports = RegisterBusinessCustomer
