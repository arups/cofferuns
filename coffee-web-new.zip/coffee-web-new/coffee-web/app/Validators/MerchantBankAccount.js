'use strict'
const { formatters } = use('Validator')

class MerchantBankAccount {
  get validateAll() {
    return true
  }


  get rules() {
    return {
      sort_code: 'required|number',
      bank_name: 'required',
      account_number: 'required|number',

    }
  }

  get messages() {
    return {
      'required': '{{ field }} is required',
      'number': 'Only numbers are allowed for {{ field }}',
    }
  }

  get formatter() {
    return formatters.JsonApi
  }

  async fails(errorMessages) {
    this.ctx.session.flash({ type: 'danger', message: errorMessages.errors[0].detail }).flashAll()
    return this.ctx.response.redirect('back')
  }
}


module.exports = MerchantBankAccount
