'use strict'
const { formatters } = use('Validator')

class MerchantDetailsForm1 {
  get validateAll () {
    return true
  }

 
  get rules() {
    return {
      business_type: 'required',
      locations: 'required',
      first_name: 'required|min:3|max:30',
      last_name: 'required|min:3|max:30',
      phone_number: 'required|number',
      business_email: 'required|email',
    }
  }

  get messages() {
    return {
      'required': '{{ field }} is required',
      'max': 'Maximum length allowed for {{ field }} is {{ argument.0 }}',
      'min': '{{ field }} must contain at least {{ argument.0 }} characters',
      'number': 'Only numbers are allowed for {{ field }}',
      'email': '{{ field }} must be a valid email',
      'email.unique': '{{ field }} already registered',

    }
  }

  get formatter() {
    return formatters.JsonApi
  }

  async fails(errorMessages) {
    this.ctx.session.flash({ type: 'danger', message: errorMessages.errors[0].detail }).flashAll()
        return this.ctx.response.redirect('back')
  }
}


module.exports = MerchantDetailsForm1

