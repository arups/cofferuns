'use strict'
const { formatters } = use('Validator')

class MerchantBasic {
  get validateAll() {
    return true
  }


  get rules() {
    return {
      restaurant_name: 'required',
      restaurant_address: 'required|min:6|max:255',
      email: 'required|email|unique:users,email',
      mobile_number: 'required|number',
      password: 'required|min:3|max:16',

    }
  }

  get messages() {
    return {
      'required': '{{ field }} is required',
      'max': 'Maximum length allowed for {{ field }} is {{ argument.0 }}',
      'min': '{{ field }} must contain at least {{ argument.0 }} characters',
      'number': 'Only numbers are allowed for {{ field }}',
      'email': '{{ field }} must be a valid email',
      'email.unique': '{{ field }} already registered',

    }
  }

  get formatter() {
    return formatters.JsonApi
  }

  async fails(errorMessages) {
    this.ctx.session.flash({ type: 'danger', message: errorMessages.errors[0].detail }).flashAll()
    return this.ctx.response.redirect('back')
  }
}


module.exports = MerchantBasic
