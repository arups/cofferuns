'use strict'
const { formatters } = use('Validator')

class UpdateMerchant {
  get validateAll() {
    return true
  }


  get rules() {
    let rules = {
      "restaurant_name": "required",
      "restaurant_address": "required",
      "business_type": "required",
      "locations": "required",
      "phone_number": "required",
      "business_email": "required",
      "menu_website": "required",
      "image": "file|file_ext:png,jpg,jpeg,PNG,JPG,JPEG|file_size:10mb|file_types:image",
      "delivery_available": "required",
      "delivery_charges": "required",
      "legal_business_name": "required",
      "vat_number": "required",
      "legal_name": "required",
      "date_of_birth": "required",
      "sort_code": "required",
      "bank_name": "required",
      "account_number": "required",
    }
    if (!this.ctx.request.file('image')) {
      delete rules.image
    }
    return rules
  }

  get messages() {
    return {
      'required': '{{ field }} is required',
      'max': 'Maximum length allowed for {{ field }} is {{ argument.0 }}',
      'min': '{{ field }} must contain at least {{ argument.0 }} characters',
      'number': 'Only numbers are allowed for {{ field }}',
      'email': '{{ field }} must be a valid email',
      'email.unique': '{{ field }} already registered',

    }
  }

  get formatter() {
    return formatters.JsonApi
  }

  async fails(errorMessages) {
    this.ctx.session.flash({ type: 'danger', message: errorMessages.errors[0].detail }).flashAll()
    return this.ctx.response.redirect('back')
  }
}

module.exports = UpdateMerchant
