'use strict'
const { formatters } = use('Validator')

class AddMenu {
  get validateAll() {
    return true
  }
  get rules() {
    let rule = {
      name: 'required|max:255',
      category_id: 'required',
      description: 'required|max:255',
      price: 'required|max:255',
      image: 'file|file_ext:png,jpg,jpeg,jfif,PNG,JPG,JPEG,JFIF|file_size:10mb|file_types:image',
    }
    if (this.ctx.request.url().includes('edit')) {
      if (!this.ctx.request.file('image')) {
        delete rule.image
      }
    }
    return rule
  }

  get messages() {
    return {
      'required': '{{ field }} is required',
      'max': 'Maximum length allowed for {{ field }} is {{ argument.0 }}',
    }
  }

  get formatter() {
    return formatters.JsonApi
  }

  async fails(errorMessages) {
    this.ctx.session.flash({ type: 'danger', message: errorMessages.errors[0].detail }).flashAll()
    return this.ctx.response.redirect('back')
  }
}

module.exports = AddMenu

