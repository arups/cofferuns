'use strict'
const { formatters } = use('Validator')

class CustomerEditProfile {
  get validateAll() {
    return true
  }


  get rules() {
    return {
      first_name: 'required|min:3|max:30',
      last_name: 'required|min:3|max:30',
      mobile_number: 'required|number',
    }
  }

  get messages() {
    return {
      'required': '{{ field }} is required',
      'max': 'Maximum length allowed for {{ field }} is {{ argument.0 }}',
      'min': '{{ field }} must contain at least {{ argument.0 }} characters',
      'number': 'Only numbers are allowed for {{ field }}',
    }
  }

  get formatter() {
    return formatters.JsonApi
  }

  async fails(errorMessages) {
    this.ctx.session.flash({ type: 'danger', message: errorMessages.errors[0].detail }).flashAll()
    return this.ctx.response.redirect('back')
  }
}

module.exports = CustomerEditProfile
