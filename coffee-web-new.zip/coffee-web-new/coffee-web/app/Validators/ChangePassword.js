'use strict'
const { formatters } = use('Validator')

class ChangePassword {
  get validateAll() {
    return true
  }


  get rules() {
    return {
      password: 'required|confirmed|min:3|max:16',
    }
  }

  get messages() {
    return {
      'required': '{{ field }} is required',
      'password.confirmed': 'Confirm password must be same as password',

    }
  }

  get formatter() {
    return formatters.JsonApi
  }

  async fails(errorMessages) {
    this.ctx.session.flash({ type: 'danger', message: errorMessages.errors[0].detail }).flashAll()
    return this.ctx.response.redirect('back')
  }
}

module.exports = ChangePassword
