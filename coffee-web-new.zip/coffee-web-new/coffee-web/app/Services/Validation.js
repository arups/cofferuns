'use strict'
    const { validate } = use('Validator');
    const Config    = use('Config');

    async function validates ( params , identifier ) {
        let rules = Config.get('rules.'+identifier);
        let messages = Config.get('messages.'+identifier);
        const validation = await validate(params, rules, messages)
        if (validation.fails()) {
            return validation.messages();
        }else{
            return true;
        }
    }
  
    module.exports =  {
        validates
    }
  