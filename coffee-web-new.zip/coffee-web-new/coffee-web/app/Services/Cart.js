
'use strict';
const Menu = use('App/Models/Menu')

const config = require('./config');


class Cart {
  static async addToCart(merchant_id = null, id = null, qty = 1, cart) {
    const menu = await Menu.find(id)
    const item = menu.toJSON()
    let prod = {
      id,
      name: item.name,
      image: item.image,
      price: item.price,
      qty,
      merchant_id
    };
    if (!cart) {
      const items = []
      cart = {}
      items.push(prod)
      cart.items = items;
      cart = this.calculateTotals(cart);
    }
    else {

      if (!this.inCart(id, cart)) {
        const items = cart.items
        cart = {}
        items.push(prod)
        cart.items = items;
        cart = this.calculateTotals(cart);
      }
      else {
        cart = this.calculateTotals(cart);

      }

    }
    return cart
  }

  static inCart(productID = 0, cart) {
    let found = false;
    cart.items.forEach((item, value) => {
      if (item.id == productID) {
        found = true;
        cart.items[value].qty += 1
      }
    });
    return found;
  }


  static calculateTotals(cart) {
    cart.totals = 0.00;
    cart.items.forEach(item => {
      let price = item.price;
      let qty = item.qty;

      let amount = price * qty;

      cart.totals += amount;
    });
    return cart
    //this.setFormattedTotals(cart);
  }

  static async removeFromCart(id = 0, cart) {

    for (let i = 0; i < cart.items.length; i++) {
      let item = cart.items[i];
      if (item.id === id) {
        cart.items.splice(i, 1);
        this.calculateTotals(cart);
      }
    }

    return cart

  }

  static async updateCart(ids = [], qtys = [], cart) {

    let map = [];
    let updated = false;

    ids.forEach((value, i) => {
      //qtys.forEach(qty => {
      map.push({
        id: parseInt(value, 10),
        qty: parseInt(qtys[i], 10)
      });
      //});
    });
    map.forEach(obj => {
      cart.items.forEach(item => {
        if (item.id == obj.id) {
          console.log("obj.qty", obj.qty)
          console.log("item.qty", item.qty)

          if (obj.qty > 0 && obj.qty != item.qty) {

            item.qty = obj.qty;
            updated = true;
          }
        }
      });
    });
    if (updated) {
      this.calculateTotals(cart);
      return cart
    }
  }




  static emptyCart(request) {

    if (request.session) {
      request.session.cart.items = [];
      request.session.cart.totals = 0.00;
      request.session.cart.formattedTotals = '';
    }


  }

  static setFormattedTotals(cart) {
    let format = new Intl.NumberFormat(config.locale.lang, { style: 'currency', currency: config.locale.currency });
    let totals = cart.totals;
    cart.formattedTotals = format.format(totals);
  }

}

module.exports = Cart;