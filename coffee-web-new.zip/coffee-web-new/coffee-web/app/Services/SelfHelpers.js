'use strict'
const { validate } = use('Validator');
const Config = use('Config');
const fs = require("fs");

const Helpers = use("Helpers");
const public_path = Helpers.publicPath();

async function uploadImage(request, folder) {
  const folder_path = `/uploads/${folder}/`
  const path_to = `${public_path}${folder_path}`
  let uploaded = { is_uploaded: true, upload_response: {} };
  const image_validation_rules = {
    size: "10mb",
    extnames: ["png", "gif", "jpeg", "jpg", "PNG", "GIF", "JPEG", "JPG", "PDF", "pdf", "jfif", "JFIF"],
  };
  const uploadedImage = request.file("image", image_validation_rules);

  const file_name = Date.now() + Math.floor(Math.random() * 100) + "." + uploadedImage.subtype
  const uploaded_path = `${folder_path}${file_name}`
  await uploadedImage.move(path_to, {
    name: file_name,
    overwrite: true,
  });

  if (!uploadedImage.moved()) {
    const errorMsg = uploadedImage.error();
    let response_code = "";
    switch (errorMsg.type) {
      case "extname":
        response_code = "IMAGE_EXTENSION_NOT_ALLOWED";
        break;
      case "size":
        response_code = "IMAGE_SIZE_EXCEED";
        break;
      default:
        response_code = "IMAGE_VALIDATIONS_FAIL";
        break;
    }

    uploaded.upload_response = response_code;
    uploaded.is_uploaded = false;
    return uploaded;
  }
  uploaded.file_name = uploaded_path
  return uploaded;
}

function getRetunrRoute(role_id) {
  let return_to = ""
  if (role_id == 1) {
    return_to = "/admin/users/mrechants"
  }
  else
    if (role_id == 2) {
      return_to = "/merchant/orders"
    }
    else
      if (role_id == 3) {
        return_to = "/success"
      }
      else {
        return_to = "/"
      }
  return return_to;
}

function getFormData(session, key) {
  let basic_data = {}
  let form_Data = session.get(key);
  if (form_Data) {
    basic_data = { ...form_Data }
  }
  return basic_data
}

function capitalizeFirstLetter(string) {
  return string.charAt(0).toUpperCase() + string.slice(1);
}

function isBase64(str) {
  //assertString(str); // remove this line and make sure you pass in a string
  const len = str.length;
  const notBase64 = /[^A-Z0-9+\/=]/i;
  if (!len || len % 4 !== 0 || notBase64.test(str)) {
    return false;
  }
  const firstPaddingChar = str.indexOf("=");
  return (
    firstPaddingChar === -1 ||
    firstPaddingChar === len - 1 ||
    (firstPaddingChar === len - 2 && str[len - 1] === "=")
  );
}

function uploadBase64Img(str, folder) {

  if (str) {

    const imgname = new Date().getTime().toString() + "_" + Math.floor(Math.random() * 1000) + ".jpeg";
    // to declare some path to store your converted image

    const folder_path = `/uploads/${folder}/${imgname}`
    const path = `${public_path}${folder_path}`
    // image takes from body which you uploaded
    const imgdata = str
    // to convert base64 format into random filename
    const base64Data = imgdata.replace(
      /^data:([A-Za-z-+/]+);base64,/,
      ""
    );
    return new Promise(function (resolve, reject) {
      fs.writeFile(path, base64Data, "base64", (err) => {
        console.log(err);
        resolve(folder_path);
      });
    });
  }
};

module.exports = {
  uploadImage,
  getRetunrRoute,
  getFormData,
  capitalizeFirstLetter,
  isBase64,
  uploadBase64Img

}
