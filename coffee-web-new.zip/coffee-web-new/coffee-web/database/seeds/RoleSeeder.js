'use strict'
const Database = use('Database')
const Model = use('App/Models/Role')
/*
|--------------------------------------------------------------------------
| RoleSeeder
|--------------------------------------------------------------------------
|
| Make use of the Factory instance to seed database with dummy data or
| make use of Lucid models directly.
|
*/

/** @type {import('@adonisjs/lucid/src/Factory')} */

class RoleSeeder {
  async run () {
    let obj = [
      {
        "id": 1,
        "name": "Admin",
      },
      {
        "id": 2,
        "name": "Merchant",
      },
      {
        "id": 3,
        "name": "Business Customer",
      },
      {
        "id": 4,
        "name": "Customer",
      },

  ]
  await Model.createMany(obj)
  }
}

module.exports = RoleSeeder
