'use strict'
const Database = use('Database')
const Model = use('App/Models/OrderTime')
/*
|--------------------------------------------------------------------------
| OrderTimeSeeder
|--------------------------------------------------------------------------
|
| Make use of the Factory instance to seed database with dummy data or
| make use of Lucid models directly.
|
*/

/** @type {import('@adonisjs/lucid/src/Factory')} */

class OrderTimeSeeder {
  async run() {
    let obj = [
      {
        "id": 1,
        "time": "15",
      },
      {
        "id": 2,
        "time": "20",
      },
      {
        "id": 3,
        "time": "30",
      },
      {
        "id": 4,
        "time": "40",
      },
      {
        "id": 5,
        "time": "50",
      },
      {
        "id": 6,
        "time": "60",
      },
      {
        "id": 7,
        "time": "75",
      },
      {
        "id": 8,
        "time": "90",
      },
    ]
    await Model.createMany(obj)
  }
}

module.exports = OrderTimeSeeder
