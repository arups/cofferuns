'use strict'
const Database = use('Database')
const Model = use('App/Models/WeekDay')
/*
|--------------------------------------------------------------------------
| WeekDaySeeder
|--------------------------------------------------------------------------
|
| Make use of the Factory instance to seed database with dummy data or
| make use of Lucid models directly.
|
*/

/** @type {import('@adonisjs/lucid/src/Factory')} */

class WeekDaySeeder {
  async run() {
    let obj = [
      {
        "id": 1,
        "name": "Monday",
      },
      {
        "id": 2,
        "name": "Tuesday",
      },
      {
        "id": 3,
        "name": "Wednesday",
      },
      {
        "id": 4,
        "name": "Thursday",
      },
      {
        "id": 5,
        "name": "Friday",
      },
      {
        "id": 6,
        "name": "Saturday",
      },
      {
        "id": 7,
        "name": "Sunday",
      },

    ]
    await Model.createMany(obj)
  }
}

module.exports = WeekDaySeeder
