'use strict'
const Database = use('Database')
const Model = use('App/Models/Hour')
/*
|--------------------------------------------------------------------------
| HourSeeder
|--------------------------------------------------------------------------
|
| Make use of the Factory instance to seed database with dummy data or
| make use of Lucid models directly.
|
*/

/** @type {import('@adonisjs/lucid/src/Factory')} */

class HoursSeeder {
  async run() {
    let obj = [
      {
        "id": 1,
        "hour": "12 AM",
      },
      {
        "id": 2,
        "hour": "01 AM",
      },
      {
        "id": 3,
        "hour": "02 AM",
      },
      {
        "id": 4,
        "hour": "03 AM",
      },
      {
        "id": 5,
        "hour": "04 AM",
      },
      {
        "id": 6,
        "hour": "05 AM",
      },
      {
        "id": 7,
        "hour": "06 AM",
      },
      {
        "id": 8,
        "hour": "07 AM",
      },
      {
        "id": 9,
        "hour": "08 AM",
      },
      {
        "id": 10,
        "hour": "09 AM",
      },
      {
        "id": 11,
        "hour": "10 AM",
      },
      {
        "id": 12,
        "hour": "11 AM",
      },

      {
        "id": 13,
        "hour": "12 PM",
      },
      {
        "id": 14,
        "hour": "01 PM",
      },
      {
        "id": 15,
        "hour": "02 PM",
      },
      {
        "id": 16,
        "hour": "03 PM",
      },
      {
        "id": 17,
        "hour": "04 PM",
      },
      {
        "id": 18,
        "hour": "05 PM",
      },
      {
        "id": 19,
        "hour": "06 PM",
      },
      {
        "id": 20,
        "hour": "07 PM",
      },
      {
        "id": 21,
        "hour": "08 PM",
      },
      {
        "id": 22,
        "hour": "09 PM",
      },
      {
        "id": 23,
        "hour": "10 PM",
      },
      {
        "id": 24,
        "hour": "11 PM",
      },
    ]
    await Model.createMany(obj)
  }
}

module.exports = HoursSeeder
