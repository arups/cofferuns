'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class OrderItemsSchema extends Schema {
  up() {
    this.create('order_items', (table) => {
      table.increments()
      table.integer('order_id').unsigned().references('id').inTable('orders')
      table.integer('product_id').unsigned().references('id').inTable('menus')
      table.string('name', 255).nullable()
      table.string('quantity', 255).nullable()
      table.string('total_cost', 255).nullable()
      table.timestamps()
    })
  }

  down() {
    this.drop('order_items')
  }
}

module.exports = OrderItemsSchema
