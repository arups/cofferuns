'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class AddIsCompletedToOrdersTableSchema extends Schema {
  up() {
    this.alter('orders', (table) => {
      table.integer('is_completed', 2).after('cutlery_info').nullable();
    })
  }

  down() {

  }
}

module.exports = AddIsCompletedToOrdersTableSchema
