'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class BusinessCustomerSchema extends Schema {
  up () {
    this.create('business_customers', (table) => {
      table.increments()
      table.integer('user_id').unsigned().references('id').inTable('users');
      table.string('user_name', 100).notNullable()
      table.string('business_owner', 100).nullable()
      table.string('business_name', 100).nullable()
      table.string('business_website', 255).nullable()
      table.string('phone_number', 30).nullable()
      table.string('business_address', 255).nullable()
      table.string('country', 100).nullable()
      table.string('city', 100).nullable()
      table.string('post_code', 20).nullable()
      table.string('street_address_1', 255).nullable()
      table.string('street_address_2', 255).nullable()
      table.timestamps()
    })
  }

  down () {
    this.drop('business_customers')
  }
}

module.exports = BusinessCustomerSchema
