'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class MerchantBusinessHoursSchema extends Schema {
  up() {
    this.create('merchant_business_hours', (table) => {
      table.increments()
      table.integer('user_id').unsigned().references('id').inTable('users')
      table.integer('week_day_id').unsigned().references('id').inTable('week_days')
      table.string('start_time', 50).notNullable()
      table.string('end_time', 50).notNullable()
      table.boolean('is_open').nullable()
      table.timestamps()
    })
  }

  down() {
    this.drop('merchant_business_hours')
  }
}

module.exports = MerchantBusinessHoursSchema
