'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class OrderTimeSchema extends Schema {
  up() {
    this.create('order_times', (table) => {
      table.increments()
      table.string('time', 20).notNullable()
      table.boolean('is_deleted').defaultTo(false)
      table.timestamps()
    })
  }

  down() {
    this.drop('order_times')
  }
}

module.exports = OrderTimeSchema
