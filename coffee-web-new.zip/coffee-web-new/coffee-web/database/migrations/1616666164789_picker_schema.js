'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class PickerSchema extends Schema {
  up() {
    this.create('picker', (table) => {
      table.increments()
      table.integer('order_id').unsigned().references('id').inTable('orders')
      table.string('name', 100).notNullable()
      table.string('contact', 50).notNullable()

      table.timestamps()
    })
  }

  down() {
    this.drop('picker')
  }
}

module.exports = PickerSchema
