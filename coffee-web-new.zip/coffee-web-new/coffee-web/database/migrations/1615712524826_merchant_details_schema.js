'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class MerchantDetailsSchema extends Schema {
  up() {
    this.create('merchant_details', (table) => {
      table.increments()
      table.integer('user_id').unsigned().references('id').inTable('users');
      table.boolean('is_activated').defaultTo(false)
      table.boolean('is_business_hours').defaultTo(false)
      table.string('restaurant_name', 255).nullable()
      table.string('restaurant_address', 255).nullable()
      table.string('restaurant_lat', 60).nullable()
      table.string('restaurant_lng', 60).nullable()
      table.string('zip_code', 60).nullable()
      table.string('business_type', 255).nullable()
      table.string('locations', 255).nullable()
      table.integer('phone_number', 30).nullable()
      table.string('business_email', 255).nullable()
      table.string('menu_website', 255).nullable()
      table.string('image', 255).nullable()
      table.string('delivery_available', 10).nullable()
      table.string('delivery_charges', 255).nullable()
      table.string('opening_hours', 255).nullable()
      table.string('legal_business_name', 255).nullable()
      table.integer('vat_number').nullable()
      table.string('legal_name', 255).nullable()
      table.string('date_of_birth', 255).nullable()
      table.string('sort_code', 255).nullable()
      table.string('bank_name', 255).nullable()
      table.string('account_number', 255).nullable()
      table.timestamps()
    })
  }

  down() {
    this.drop('merchang_details')
  }
}

module.exports = MerchantDetailsSchema
