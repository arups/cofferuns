'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class AddColumnCutleryInfoSchema extends Schema {
  up() {
    this.alter('orders', (table) => {
      table.string('cutlery_info', 500).after('delivery_address').nullable();
    })
  }

  down() {

  }
}

module.exports = AddColumnCutleryInfoSchema
