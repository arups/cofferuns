'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class MenuCategoriesSchema extends Schema {
  up() {
    this.create('menu_categories', (table) => {
      table.increments()
      table.integer('user_id').unsigned().references('id').inTable('users')
      table.string('name', 255).notNullable()
      table.boolean('is_deleted').defaultTo(false)
      table.timestamps()
    })
  }

  down() {
    this.drop('menu_categories')
  }
}

module.exports = MenuCategoriesSchema
