'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class HoursSchema extends Schema {
  up() {
    this.create('hours', (table) => {
      table.increments()
      table.string('hour', 50).notNullable()
      table.boolean('is_deleted').defaultTo(false)
      table.timestamps()
    })
  }

  down() {
    this.drop('hours')
  }
}

module.exports = HoursSchema
