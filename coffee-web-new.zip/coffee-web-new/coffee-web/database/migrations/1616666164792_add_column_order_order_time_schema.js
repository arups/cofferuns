'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class AddIsCompletedToOrdersTableSchema extends Schema {
  up() {
    this.alter('orders', (table) => {
      table.integer('time_required').after('amount').unsigned().references('id').inTable('order_times')
    })
  }

  down() {

  }
}

module.exports = AddIsCompletedToOrdersTableSchema
