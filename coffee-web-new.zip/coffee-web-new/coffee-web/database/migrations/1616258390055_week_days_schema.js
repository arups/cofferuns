'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class WeekDaysSchema extends Schema {
  up() {
    this.create('week_days', (table) => {
      table.increments()
      table.string('name', 50).notNullable()
      table.boolean('is_deleted').defaultTo(false)
      table.timestamps()
    })
  }

  down() {
    this.drop('week_days')
  }
}

module.exports = WeekDaysSchema
