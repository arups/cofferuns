'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class UserSchema extends Schema {
  up() {
    this.create('users', (table) => {
      table.increments()
      table.string('first_name', 30).notNullable()
      table.string('last_name', 30).notNullable()
      table.string('email', 254).notNullable().unique()
      table.string('mobile_number', 30).notNullable()
      table.integer('role_id', 4).unsigned().references('id').inTable('roles')
      table.boolean('is_active').defaultTo(true)
      table.boolean('is_deleted').defaultTo(false)
      table.string('password', 255).notNullable()
      table.timestamps()
    })
  }

  down() {
    this.drop('users')
  }
}

module.exports = UserSchema
