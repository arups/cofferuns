
$(document).ready(async function () {
    let ip = $("#ip_address").val()
    var access_key = 'd92a54ba37c19e642ecae99fd76d0a98';

    // get the API result via jQuery.ajax
    $.ajax({
        url: 'http://api.ipstack.com/' + ip + '?access_key=' + access_key,
        dataType: 'jsonp',
        success: function (json) {
            console.log(json.latitude);
            console.log(json.longitude);
            if(!json.latitude)
            {
              initMap(51.5074, 0.1278);
            }
            else {
              initMap(json.latitude, json.longitude);
            }


        }
    });
});



$("#restaurant_address").focus(function () {
    $("#selectLocation").modal("show");
});

$("#restaurant_address").click(function () {
    $("#selectLocation").modal("show");
});


$('#modalClose').bind('click', function () {
    const pathname = location.pathname.substring(1);
    const parts = pathname.split(/\//);
    if (parts.length == 1 && parts[0] == "") {
        $("#search_restaurant_anchor")[0].click();
    }
    else {
        $("#selectLocation").modal("hide");
    }
});

function initMap(lat = 51.4827716779654, lng = -0.11599077930613019) {
    var geocoder = new google.maps.Geocoder();
    const initialLocation = { lat, lng };
    // London

    //51.4827716779654, -0.11599077930613019
    //const initialLocation = { lat: 30.852328423322216, lng: 72.54722605981621 };
    var myOptions = {
        zoom: 13,
        center: initialLocation,
        disableDefaultUI: true,
        zoomControl: true,
        zoomControlOptions: {
            style: google.maps.ZoomControlStyle.SMALL
        },
        mapTypeId: 'roadmap',
        draggableCursor: 'crosshair',
        draggingCursor: 'move'
    }
    var map = new google.maps.Map(document.getElementById("map"), myOptions);
    var marker;

    map.addListener('click', handleEvent)

    function placeMarker(location, address) {
        if (marker) {
            marker.setPosition(location);
        } else {
            marker = new google.maps.Marker({
                position: location,
                // draggable: true,
                map: map
            });
        }

        marker.addListener('drag', handleEvent);
        marker.addListener('dragend', handleEvent);
    }

    function handleEvent(event) {
        geocoder.geocode({
            'latLng': event.latLng
        }, function (results, status) {
            if (status == google.maps.GeocoderStatus.OK) {
                if (results[0]) {
                    address = results[0].formatted_address
                    const loc_lat = event.latLng.lat()
                    const loc_lng = event.latLng.lng()
                    //If we are on merchant basic information form
                    if (document.getElementById("merchantBasicForm")) {
                        for (j = 0; j < results[0].address_components.length; j++) {
                            if (results[0].address_components[j].types[0] == 'postal_code')
                                document.getElementById('zip_code').value = results[0].address_components[j].short_name
                        }

                        document.getElementById('restaurant_lat').value = loc_lat
                        document.getElementById('restaurant_lng').value = loc_lng
                        document.getElementById('restaurant_address').value = address
                    }

                    if (document.getElementById("searchRestForm")) {
                        const latLngCommaSeparated = loc_lat + "," + loc_lng
                        document.getElementById('restaurant_address').value = latLngCommaSeparated
                        const a = document.getElementById('search_restaurant_anchor'); //or grab it by tagname etc
                        a.href = `/restaurants?lat=${loc_lat}&lng=${loc_lng}&address=${address}`
                        document.getElementById('customer_address').value = address

                    }
                    placeMarker(event.latLng, address)
                }
            }
        })
    }
}

