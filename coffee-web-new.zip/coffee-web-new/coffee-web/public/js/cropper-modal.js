$(document).ready(function () {
    var $modal = $('#modal');

    var image = document.getElementById('sample_image');

    var cropper;

    $('#image').change(function (event) {
        var files = event.target.files;

        var done = function (url) {
            image.src = url;
            $modal.modal('show');
        };

        if (files && files.length > 0) {
            reader = new FileReader();
            reader.onload = function (event) {
                done(reader.result);
            };
            reader.readAsDataURL(files[0]);
        }
    });
    $modal.on('shown.bs.modal', function () {
        cropper = new Cropper(image, {
            aspectRatio: 11 / 9,
            viewMode: 0,
            center: true,
            dragMode: 'move',
            movable: true,
            scalable: true,
            guides: true,
            zoomOnWheel: true,
            cropBoxMovable: true,
            wheelZoomRatio: 0.1,
            preview: '.preview',


        });
    }).on('hidden.bs.modal', function () {
        cropper.destroy();
        cropper = null;
    });

    $('#crop').click(function () {
        var cropped = document.querySelector('.croppedImage')
        var img_data = document.querySelector('.img_data')
        let imgSrc = cropper.getCroppedCanvas({
            width: 125,
            height: 255,
        }).toDataURL();
        cropped.src = imgSrc;
        img_data.value = imgSrc;
        cropped.classList.remove('d-none');
        $modal.modal('hide');
    });

    /********************************************************* */
    $('input[type=radio][name="additional-info"]').change(function () {
        alert($(this).val());
    });

});