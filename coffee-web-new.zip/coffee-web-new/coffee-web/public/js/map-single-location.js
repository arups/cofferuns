$(document).ready(function () {
    let latlng = { lat: parseFloat($("#lat").val()), lng: parseFloat($("#lng").val()) }
    console.log("WORKING FINE")
    //initMap(latlng)
});


function initMap(latLngVal) {
    const name = $("#restaurant_name").val()
    const latLng = { lat: parseFloat($("#lat").val()), lng: parseFloat($("#lng").val()) };
    const map = new google.maps.Map(document.getElementById("map"), {
        center: latLng,
        zoom: 13,
        disableDefaultUI: true,
        zoomControl: true,
        zoomControlOptions: {
            style: google.maps.ZoomControlStyle.SMALL
        },
        mapTypeId: 'roadmap',
        draggableCursor: 'crosshair',
        draggingCursor: 'move'



    });
    new google.maps.Marker({
        position: latLng,
        map,
        title: name,
    });
}