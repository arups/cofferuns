
$(document).ready(function () {
    console.log("aaaaaaaaaaaaaaaaaaaaa")
    $(".order-savetime-btn").click(function (e) {
        console.log("aaaaaaaaaaaaaaaaaaaaa")

        e.preventDefault();
        const order_id = this.getAttribute("data-order-id");
        const time_val = $(`#order_time_${order_id}`).val()
        window.location = `/merchant/order/${order_id}/${time_val}/time`

    });
});