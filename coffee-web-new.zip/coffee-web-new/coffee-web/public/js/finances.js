$(document).ready(function () {
    getFinances()
});



function getFinances(queryString) {

    let formData = new FormData();
    formData.append("_csrf", $('[name=_csrf]').val())
    fetch(`/merchant/get-finances`, {
        method: "GET",
        data: formData
    }).then((response) => response.json())
        .then(success);
    // ENd fetch
}

function success(response) {
    const chart = Highcharts.chart('chart-container', {
        chart: {
            type: 'column'
        },
        xAxis: {
            categories: response.categories
        },
        title: {
            text: 'Order Volume (Last 10 Days)'
        },
        plotOptions: {
            series: {
                allowPointSelect: false,
            },
        },
        credits: {
            enabled: false
        },
        series: [{
            data: response.orders,
            showInLegend: false,
        }]
    });

    document.getElementById('button').addEventListener('click', () => {
        const selectedPoints = chart.getSelectedPoints();

        if (chart.lbl) {
            chart.lbl.destroy();
        }
        chart.lbl = chart.renderer.label('You selected ' + selectedPoints.length + ' points', 100, 60)
            .attr({
                padding: 10,
                r: 5,
                fill: Highcharts.getOptions().colors[1],
                zIndex: 5
            })
            .css({
                color: 'white'
            })
            .add();
    });

}

