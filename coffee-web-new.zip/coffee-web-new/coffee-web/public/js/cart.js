function addCultery() {

    let info = $("#cutleryInformations").val().trim()
    if (info == "") {
        $("#cutleryInformationsError").removeClass('d-none')
    }
    else {
        console.log(info)
        fetch(`/add/cutlery?info=${info}`, {
            method: "GET",
        }).then((response) => response.json())
            .then(addCutlerysuccess);
    }
}

$('#cutleryModal').on('show.bs.modal', function (e) {
    $("#cutleryInformationsError").addClass('d-none')
});

$('#cutleryModal').on('hidden.bs.modal', function (e) {
    console.log("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")
    $("#cutleryInfo").prop('checked', false);
});

function addCutlerysuccess(response) {
    console.log(response)
    $('#cutleryModal').modal('hide')
    $("#cutleryInformationsError").addClass('d-none')
    $("#cutleryInfo").attr("disabled", true);
}

$('#cutleryInfo').on('change.bootstrapSwitch', function (e) {
    if (e.target.checked) {
        $('#cutleryModal').modal('show')
    }
});

function fixedtoTwoDecimal() {
    $('.cart-num').map(function () {
        const val = parseFloat(this.innerText).toFixed(2)
        this.innerText = "£" + val
    })


}

$(document).ready(function () {
    const pathname = location.pathname.substring(1);
    const parts = pathname.split(/\//);
    if (parts.length == 2) {
        if (parts[0] == 'my' && parts[1] == 'cart') {
            fixedtoTwoDecimal();
        }
    }

    $(".addTOCartBtn").click(function (e) {
        e.preventDefault();
        $('button').attr("disabled", true);
        const product_id = this.getAttribute("data-product-id");
        const merchant_id = this.getAttribute("data-merchant");
        fetch(`/add-to/${merchant_id}/${product_id}/cart`, {
            method: "GET",
        }).then((response) => response.json())
            .then(success);
    });

    $(".removeCartBtn").click(function (e) {
        e.preventDefault();
        const product_id = this.getAttribute("data-product-id");
        var tr = $(this).closest("tr");
        tr.remove();
        fetch(`/remove/${product_id}/item`, {
            method: "GET",
        }).then((response) => response.json())
            .then(removeSuccess);
    });


    $(".refreshBtn").click(function (e) {
        e.preventDefault();
        let ids = []
        let qtys = []
        const alltbs = $($('.item-qty'))
        for (let i = 0; i < alltbs.length; i++) {
            ids.push(alltbs[i].getAttribute("data-product-id"));
            qtys.push(alltbs[i].value);

        }

        var formData = new FormData();
        formData.ids = ids
        formData.qtys = qtys

        $.ajax({
            type: 'GET',
            url: `/update/cart?ids=${ids.join()}&qtys=${qtys.join()}`,
            data: formData,
            async: true,
            success: function (data) {
                updateeSuccess(data)
            },
            cache: false,
            contentType: false,
            processData: false
        });
    });


    function success(response) {
        $('button').attr("disabled", false);
        $('#cartMessage').text('Item added to cart successfully')
        $("#cartPopUpDiv").fadeIn('slow').delay(1500).fadeOut('slow');

        $("#lblCartCount").text(response.cart_items.items.length)
    }

    function removeSuccess(response) {

        $('#cartMessage').text('Item removed successfully')
        $("#cartPopUpDiv").fadeIn('slow').delay(1500).fadeOut('slow');

        $("#lblCartCount").text(response.cart_items.items.length)
        $("#cartTotal").text("£" + parseFloat(response.cart_items.totals).toFixed(2))
    }

    function updateeSuccess(response) {
        if (response) {
            $('#cartMessage').text('Cart updated successfully')
            $("#cartPopUpDiv").fadeIn('slow').delay(1500).fadeOut('slow');
            const items = response.cart_items.items

            for (let i = 0; i < items.length; i++) {
                $(`#item_total_${items[i].id}`).text("£" + parseFloat(items[i].price * items[i].qty).toFixed(2))
            }
            $("#cartTotal").text("£" + parseFloat(response.cart_items.totals).toFixed(2))
        }
    }



    // Create an instance of the Stripe object with your publishable API key
    const key = $("#4gvKmHVbN8").val()
    var stripe = Stripe(key);
    var checkoutButton = document.getElementById('checkout-button');

    checkoutButton.addEventListener('click', function () {
        if (document.getElementById("2dvOmPVrN6").value == 0) {
            window.location = '/login?returnURL=cart'
        } else {
            // Create a new Checkout Session using the server-side endpoint you
            // created in step 3.
            let fd = new FormData();
            fd.append("_csrf", document.getElementById("_csrf").value);
            fetch('/create-checkout-session', {
                method: 'POST',

                body: fd
            })
                .then(function (response) {
                    console.log(response.body)
                    return response.json();
                })
                .then(function (session) {
                    return stripe.redirectToCheckout({ sessionId: session.id });
                })
                .then(function (result) {
                    // If `redirectToCheckout` fails due to a browser or network
                    // error, you should display the localized error message to your
                    // customer using `error.message`.
                    if (result.error) {
                        alert(result.error.message);
                    }
                })
                .catch(function (error) {
                    console.error('Error:', error);
                });
        } // check ends here
    });// clicked ends here

});

