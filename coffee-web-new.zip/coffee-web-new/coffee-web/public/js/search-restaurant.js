$(document).ready(function () {
    getCoordinates()
});


function getCoordinates() {
    let params = getQueryString()
    if (params.hasOwnProperty('zipcode')) {
        console.log("Search by zip code")

        const code = params.zipcode
        //const code = "SE11 5SL-DKL"
        fetch("https://maps.googleapis.com/maps/api/geocode/json?address=" + code + '&key=AIzaSyAIfasJ9LUbuYSgL1yC-wgh3Y0Rv5z073g')
            .then(response => response.json())
            .then(data => {
                console.log(data)
                if (data.results.length) {
                    const address = data.results[0].formatted_address;
                    const latitude = data.results[0].geometry.location.lat;
                    const longitude = data.results[0].geometry.location.lng;
                    const queryString = `lat=${latitude}&lng=${longitude}&address=${address}`
                    console.log(queryString)
                    getRestaurants(queryString)
                }
                else {
                    const message = '< div class="px-3 py-3" ><div class="alert alert-warning" role="alert"> Zipcode not dound </div> </div >'
                    $("#restaurants_list").html(message)
                }
            })

    } else {
        console.log("Search by LAT LNG")
        const queryString = Object.keys(params).map(key => key + '=' + params[key]).join('&');
        console.log(queryString)
        getRestaurants(queryString)
    }
}


function getRestaurants(queryString) {
    console.log(queryString)
    fetch(`/search/restaurants?${queryString}`, {
        method: "GET",
    }).then((response) => response.json())
        .then(success);
    // ENd fetch
}

function success(response) {
    // Generating Restaurants
    console.log(response)
    addPagination(response)
    initMap(response)
}


function addPagination(response) {
    const dataSource = response.final_restaurants_data
    console.log(dataSource)
    if (dataSource.length > 0) {
        $('#pagination-container').pagination({
            dataSource,
            pageSize: 3,
            callback: function (data, pagination) {
                var html = simpleTemplating(data);
                $('#data-container').html(html);
            }
        })
    }
    else {
        const notFound = `
        <div class='px-3 py-3'>
        <div class="alert alert-warning" role="alert">
            Restaurants Not Found
        </div>
      </div>`
        $('#data-container').html(notFound);
    }

}
function simpleTemplating(data) {
    const final_data_length = data.length
    let final_restaurants_data = data
    let Restaurants_HTML = ""
    for (let i = 0; i < final_data_length; i++) {
        let rest_day_data = final_restaurants_data[i].day_data
        let is_opened = rest_day_data.is_open ? "Opened" : "Closed"
        let media_tag_class = rest_day_data.is_open ? "media-tag" : "media-tag media-tag-yellow"

        Restaurants_HTML += ` <div class="media-list">
        <div class="media">
          <img src="${final_restaurants_data[i].image}" width="190px" class="mr-3" alt="..." />
          <div class="media-body">
            <a href="/restaurant/${final_restaurants_data[i].user_id}/menu" target='_blank' class='text-ornge'><h3 class="my-0">${final_restaurants_data[i].restaurant_name}</h3></a>
            <p class="media-description">${final_restaurants_data[i].restaurant_address}</p>
            <ul class="media-tags d-flex">
              <li class="${media_tag_class}">${is_opened}</li>
            </ul>
            <div class="media-hourse">
              <span> Open ${rest_day_data.start_time} - ${rest_day_data.end_time} </span>
            </div>
          </div>
        </div>
      </div>
      `
    }
    return Restaurants_HTML;
}


// document.getElementById("reorderAnchor").addEventListener("click", function (event) {
//     event.preventDefault()
// });


$("#reorderAnchor").click(function (e) {
    e.preventDefault();
    if (document.getElementById("2dvOmPVrN6").value == 0) {
        window.location = '/login?returnURL=reorder'
    } else {
        window.location = this.href
    }

});

function getQueryString() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars[hash[0]] = hash[1];
    }
    return vars;
}



var map;
var global_markers = [];

var infowindow = new google.maps.InfoWindow({});

function initMap(response) {
    let markers = response.data
    let cust_lat = 51.4827716779654
    let cust_lng = -0.11599077930613019

    if (response.data.length > 0) {
        cust_lat = parseFloat(markers[0][0])
        cust_lng = parseFloat(markers[0][1])
    }


    geocoder = new google.maps.Geocoder();
    var latlng = new google.maps.LatLng(cust_lat, cust_lng);
    var myOptions = {
        zoom: 13,
        center: latlng,
        mapTypeId: google.maps.MapTypeId.ROADMAP
    }
    map = new google.maps.Map(document.getElementById("map"), myOptions);
    addMarker(markers);
}

function addMarker(markers) {
    for (let i = 0; i < markers.length; i++) {
        // obtain the attribues of each marker
        let lat = parseFloat(markers[i][0]);
        let lng = parseFloat(markers[i][1]);
        let restaurant_name = markers[i][2];
        let myLatlng = new google.maps.LatLng(lat, lng);

        let marker_info = {
            position: myLatlng,
            map: map,
            //title: "Coordinates: " + lat + " , " + lng + " | Trailhead name: " + restaurant_name
        }
        if (markers[i][2] == "location") {
            restaurant_name = "Your location"
            marker_info.icon = "http://maps.google.com/mapfiles/ms/icons/green-dot.png"
        }
        let contentString = `<html><body><div>
                <p class='m-0'>${restaurant_name}</p>`
        if (markers[i][2] != "location") {
            contentString += `<p class='m-0'><a target='_blank' href='/restaurant/${markers[i][3]}/menu'>show menu</a></p>`
        }

        contentString += `  </div></body></html>`;

        let marker = new google.maps.Marker(marker_info);

        marker['infowindow'] = contentString;

        global_markers[i] = marker;

        google.maps.event.addListener(global_markers[i], 'click', function () {
            infowindow.setContent(this['infowindow']);
            infowindow.open(map, this);
        });
    }
}
