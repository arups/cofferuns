$(document).ready(function () {
    $('.custom-file-input').on('change', function (e) {
        //get the file name
        const fileName = e.target.files[0].name;
        //replace the "Choose a file" label
        $(this).next('.custom-file-label').html(fileName);
    })
})
