"use strict";

/*
|--------------------------------------------------------------------------
| Routes
|--------------------------------------------------------------------------
|
| Http routes are entry points to your web application. You can create
| routes for different URL's and bind Controller actions to them.
|
| A complete guide on routing is available here.
| http://adonisjs.com/docs/4.1/routing
|
*/

/** @type {typeof import('@adonisjs/framework/src/Route/Manager')} */
const Route = use("Route");

Route.get("/", "HomeController.index").as("home").middleware(['cart_items_count']);
Route.get("/getData", "RetailCustomerController.index").as("getData");

Route.get("/end-users-license", "HomeController.endUserLicense").as(
  "endUserLicense"
);
Route.get("/consumer-faq", "HomeController.consumerFaq").as("consumerFaq");

Route.get("/referral", "HomeController.referral").as("referral");
Route.get("/health-safety", "HomeController.healthSafety").as("healthSafety");
Route.get("/privacy", "HomeController.privacy").as("privacy");
Route.get("/terms-and-conditions", "HomeController.termsAndConditions").as(
  "termsAndConditions"
);
Route.get("/about-us", "HomeController.AboutUs").as("AboutUs");
Route.get("/contact-us", "HomeController.contactUs").as("contactUs");
Route.get("/business", "HomeController.business").as("business");
Route.get("/group-order", "HomeController.groupOrder").as("groupOrder");
Route.get("/restaurants", "HomeController.restaurants").as("restaurants");
Route.get("/404", "HomeController.notFound").as("notFound");
/*
|--------------------------------------------------------------------------
| Customer Register - ROUTES
|--------------------------------------------------------------------------
*/
Route.get("/login", "AuthController.Login").as("customer.login");
Route.post("/login", "AuthController.LoginSubmit").validator('Login').as("customer.login.submit");
Route.get("/register", "AuthController.customerRegister").as("customer.register");
Route.post("/register", "AuthController.customerRegisterSubmit").validator('RegisterCustomer').as("customer.register.submit");
Route.get('logout', 'AuthController.logout').as("logout")

/*
|--------------------------------------------------------------------------
| Business Customer Register - ROUTES
|--------------------------------------------------------------------------
*/
Route.get(
  "/business-customer/register",
  "AuthController.businessCustomerRegister"
).as("business-customer.register");

Route.post(
  "/business-customer/register",
  "AuthController.businessCustomerRegisterSubmit"
).validator('RegisterBusinessCustomer').as("business-customer.register.submit");

/*
|--------------------------------------------------------------------------
| Merchant Register - ROUTES
|--------------------------------------------------------------------------
*/
Route.get("/merchant", "AuthController.merchantBasic").as("merchantBasic");
Route.post("/merchant", "AuthController.merchantBasicSubmit").validator('MerchantBasic').as("merchantBasic.submit");


Route.get("/merchant/details/1", "AuthController.merchantDetailsForm1").as(
  "merchantDetailsForm1"
);
Route.post("/merchant/details/1", "AuthController.merchantDetailsForm1Submit")
  //.validator('merchantDetailsForm1')
  .as("merchantDetailsForm1.submit");

Route.get("/merchant/details/2", "AuthController.merchantDetailsForm2").as(
  "merchantDetailsForm2"
);
Route.post("/merchant/details/2", "AuthController.merchantDetailsForm2Submit").as(
  "merchantDetailsForm2.submit"
);
Route.get("/merchant/details/3", "AuthController.merchantDetailsForm3").as(
  "merchantDetailsForm3"
);
Route.get("/merchant/details/4", "AuthController.merchantDetailsForm4").as(
  "merchantDetailsForm4"
);

// Post
Route.post("/merchant/register", "AuthController.register").as(
  "merchant.register"
);


/*
|--------------------------------------------------------------------------
| Retail Module - Protected ROUTES
|--------------------------------------------------------------------------
*/

Route.group(() => {
  Route.get("/", "CommonController.index").as("profile");
  Route.get("profile/edit", "CommonController.editShow").as("profile.edit");
  Route.post("profile/edit", "CommonController.edit").validator("CustomerEditProfile").as("profile.edit.submit");
}).prefix("profile").middleware(["auth"]);


/*
|--------------------------------------------------------------------------
| Change Password - Protected Auth ROUTES
|--------------------------------------------------------------------------
*/
Route.group(() => {
  Route.get("/password", "PasswordController.changePassewordShow").as("profile.password");
  Route.post("/password", "PasswordController.changePasseword").validator("ChangePassword").as("profile.password.submit");
}).prefix("change").middleware(["auth"]);

/*
|--------------------------------------------------------------------------
| Merchant Module - Protected ROUTES
|--------------------------------------------------------------------------
*/

Route.group(() => {
  Route.get("/dashboard", "MerchantController.dashboard").as("merchant.dashboard");
  Route.get("/menus", "MerchantController.menus").as("menus.list");
  Route.get("/menus/add", "MerchantController.addShow").as("menus.add");
  Route.post("/menus/add", "MerchantController.add").validator('AddMenu').as("menus.add.submit");
  Route.get("/menus/edit/:id", "MerchantController.editShow").as("menus.edit");
  Route.post("/menus/edit/:id", "MerchantController.edit").validator('AddMenu').as("menus.edit.submit");
  Route.get("/menu/status/:id/:action", "MerchantController.changeStatus").as("menu.change.status");

  Route.get("/business-hours", "MerchantController.businessHours").as("merchant.businesshours");
  Route.post("/business-hours", "MerchantController.setBusinessHours").as("merchant.businesshours.submit");
  Route.get("/activate", "MerchantController.activate").as("merchant.activate");
  Route.post("/activate", "MerchantController.activateSubmit").as("merchant.activate.submit");
  Route.get("/bank-account", "MerchantController.bankAccount").as("merchant.bankAccount");
  Route.get("/bank-account/edit", "MerchantController.bankAccountEdit").as("merchant.bankAccountEdit");
  Route.post("/bank-account/edit", "MerchantController.bankAccountEditSubmit").validator('MerchantBankAccount').as("merchant.bankAccountEditSubmit");

  // Categories Route
  Route.get("/categories", "MerchantController.categories").as("menus.categories");
  Route.get("/categories/add", "MerchantController.addCategory").as("menus.categories.add");
  Route.post("/categories/add", "MerchantController.addCategorySubmit").validator('Category').as("menus.categories.add.submit");
  Route.get("/categories/edit/:id", "MerchantController.editCategory").as("menus.categories.edit");
  Route.post("/categories/edit/:id", "MerchantController.editCategorySubmit").validator('Category').as("menus.categories.edit.submit");
  Route.get("/categories/delete/:id", "MerchantController.deleteCategory").as("menus.categories.delete");
  // Incomming Orders
  Route.get("/orders", "MerchantController.getOrders").as("orders.list");
  Route.get("/order/:order_id/mark", "MerchantController.markOrderCompleted").as("order.mark");
  Route.post("/order/:order_id/completed", "MerchantController.markOrderSubmit").validator('Picker').as("order.mark.submit");

  Route.get("/order/:order_id/:time_id/time", "MerchantController.updateOrderTime").as("order.time");


  Route.get("/order/:order_id", "MerchantController.viewOrder").as("order.view");
  // Completed Orders
  Route.get("/orders/completed", "MerchantController.getOrders").as("orders.completed.list");



  Route.get("/:id/edit", "MerchantController.merchantEditShow").as("merchant.self.edit.show");

  Route.post(
    "/:id/edit",
    "MerchantController.updateMerchantSubmit"
  ).validator("UpdateMerchant").as("merchant.self.edit.submit");

  //Finances
  Route.get("/finances", "MerchantController.finance").as("finance");
  Route.get("/get-finances", "MerchantController.getFinance");
}).prefix("merchant").middleware(["auth", "merchant"]);


Route.get("/merchant/message", "AuthController.message").as("message");
Route.get("/send", "MerchantController.sendOrderEmail").as("sendOrderEmail");



/*
|--------------------------------------------------------------------------
| Admin - Protected ROUTES
|--------------------------------------------------------------------------
*/

Route.group(() => {
  Route.get("/users/mrechants", "AdminController.merchantList").as("merchant.list");
  Route.get("/users/business-customers", "AdminController.businessCustomerList").as("businessCustomers.list");
  Route.get("/users/retail-customers", "AdminController.retailCustomerList").as("retailCustomerList.list");
  Route.get("/users/details/:role_id/:id", "AdminController.userDetails").as("userDetails.show");
  Route.get("/users/business-customers/:role_id/:id/edit", "AdminController.businessCustomerEditShow").as("businessCustomers.edit.show");
  Route.post(
    "/users/business-customers/:role_id/:id/edit",
    "AdminController.updateBusinessCustomerSubmit"
  ).validator('RegisterBusinessCustomer').as("businessCustomers.edit.submit");

  Route.get("/users/merchant/:role_id/:id/edit", "AdminController.merchantEditShow").as("merchant.edit.show");

  Route.post(
    "/users/merchant/:role_id/:id/edit",
    "AdminController.updateMerchantSubmit"
  ).validator("UpdateMerchant").as("merchant.edit.submit");


  Route.get("/business-hours/:merchant_id", "MerchantController.businessHours").as("admin.merchant.businesshours");
  Route.post("/business-hours/:merchant_id", "MerchantController.setBusinessHours").as("admin.merchant.businesshours.submit");

  // Incomming Orders
  Route.get("/orders", "MerchantController.getOrders").as("orders.list");
  Route.get("/order/:order_id", "MerchantController.viewOrder").as("order.view");


  Route.post("/user/block", "AdminController.blockUser").as("user.block");
  Route.get("/transactions", "TransactionsController.index").as("admin.transactions");
  Route.get("/transactions/download/:format", "TransactionsController.download").as("transactions.download");
}).prefix("admin").middleware(["auth"]);

Route.get('/clear', ({ session, response }) => {
  session.clear()
  // let abc = null
  session.put('cart', "Empty");
  return "Cleared. . .aaaaaaaaaaaaaaa "
})
Route.get('/get', ({ session, response }) => {
  let ses = session.all();
  return response.json(ses)
})

Route.get('/search/restaurants', "RetailCustomerController.search")
// Re order routes
Route.get('/re-order', "CartController.reOrder").as('reorder').middleware(['cart_items_count'])
Route.get('place/re-order/:order_id', "CartController.placeReOrder").as('place-reorder')
// Re order routes
Route.get('/restaurant/:id/menu', "RetailCustomerController.restaurantMenu").middleware(['cart_items_count'])
Route.get('/my/cart', "RetailCustomerController.myCart").as("myCart").middleware(['cart_items_count'])

Route.get('/add-to/:merchant_id/:id/cart', "CartController.addToCart")
Route.get('/remove/:id/item', "CartController.removeFromCart")
Route.get('/update/cart', "CartController.updateCart")


Route.post('/create-checkout-session', "CartController.createCheckouSession").as("cart.createCheckouSession")

Route.get('/payment-success', "CartController.paymentSuccess")
Route.get('/payment-cancel', "CartController.paymentCancel")
Route.get('/add/cutlery', "CartController.addCultery")




Route.get('/checkSession', "CartController.checkSession")

Route.get("/success", "AuthController.success").as("success")

