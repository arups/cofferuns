'use strict'


async function UploadTrailorGallery(request , source_id , source_type){
    // const MediaModel = use('App/Models/Media');
    const Helpers = use('Helpers');
    if(typeof source_id!='undefined' && request.file('gallery')){
        const files = request.file('gallery', {
            types: ['image'],
            size: '2mb'
        })
        if(request.file('gallery')._files){
            const myFiles = files.files;
            await Promise.all(
                myFiles.map(async f => {
                    let random_name = await Math.random(9);
                    let filename = `${new Date().getTime()}-${random_name}.${f.subtype}`
                    await f.move(Helpers.publicPath('uploads'), {
                        name: filename
                    })
                })
            )
            let allFiles = files.all();
    
            allFiles.forEach(UploadedImage => {
                    console.log("UploadedImage.fileName" , UploadedImage.fileName);
                    let media = new MediaModel();
                    media.source_id = source_id;
                    media.source_type = source_type;
                    media.path = UploadedImage.fileName;
                    media.media_type = 'image';
                    media.save();
                    //return img;
            });
    
            let movedAll = files.movedAll()
            let movedList = files.movedList()
            return { allFiles, movedAll, movedList }

        }else{
                console.log("Single Image......");
                var imgName = `${new Date().getTime()}.jpeg`;
                await files.move(Helpers.publicPath('uploads'), {
                    name: imgName
                });
                let media = new MediaModel();
                media.source_id = source_id;
                media.source_type = source_type;
                media.path = imgName;
                media.media_type = 'image';
                media.save();
        }

    }else{
        console.log("Source id not foud");
        return false;
    }
      

}

async function UploadUserImage(request , source_id , source_type){
    const MediaModel = use('App/Models/Media');
    const Helpers = use('Helpers');
    const public_path = Helpers.publicPath();
    if(request.file('image_url')){
        const profilePics = request.file('image_url', {
            types: ['image'],
            size: '2mb'
        });
        var imgName = `${new Date().getTime()}.jpeg`;
        await profilePics.move(public_path+"/uploads/user/", {
            name: imgName
        });
        //let media = new MediaModel();
        MediaModel.source_id = source_id;
        MediaModel.source_type = source_type;
        MediaModel.path = imgName;
        MediaModel.media_type = 'image';
        MediaModel.save();
        return imgName;
    }

}


module.exports = {
    UploadTrailorGallery,
    UploadUserImage
}