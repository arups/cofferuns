'use strict'

async function success(data , message){
    
    if(data.paginate){
        var result = {
            "status":true,
            "resCode":200,
            "data": data,
            "message": message,
            "paginate":data.paginate
        }        
    }else{
        var result = {
            "status":true,
            "resCode":200,
            "data": data,
            "message": message,
        }
    }

    
    return result;

}

async function error(message){
    let result = {
        "status":false,
        "resCode":400,
        "data": null,
        "message": message,
    }
    return result;
}

async function dbOperation(status, data){
    let result = {
        "status":status,
        "data": data,
    }
    return result;
}



module.exports = {
    success,
    error,
    dbOperation
}