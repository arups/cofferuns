'use strict'

async function messages(name){
    return {
        verification_code_sent: 'Verification code has been sent to your registred phone number',
        user_already_exist: 'User already exist'
    }
    
}

async function getMessage(name){
    return messages(name)
}



module.exports = {
    getMessage
}