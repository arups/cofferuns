'use strict'
module.exports = {

  merchantDetailsForm1: {
    // Basic Form validation rules
    restaurant_name: 'required',
    restaurant_address: 'required',
    email: 'required',
    mobile_number: 'required',
    password: 'required',
    // Form 2 validation rules
    business_type: 'required',
    locations: 'required',
    first_name: 'required|min:3|max:30',
    last_name: 'required|min:3|max:30',
    phone_number: 'required|number',
    business_email: 'required|email',
  },
  merchantDetailsForm2: {
    // Basic Form validation rules
    restaurant_name: 'required',
    restaurant_address: 'required',
    email: 'required',
    mobile_number: 'required',
    password: 'required',
    // Form 1 validation rules
    business_type: 'required',
    locations: 'required',
    first_name: 'required',
    last_name: 'required',
    phone_number: 'required',
    business_email: 'required',
    // Form 2 validation rules
    menu_website: 'required',
    delivery_available: 'required',
    //delivery_charges: 'required_when:delivery_available,1',
    menu_website: 'required',
    opening_hours: 'required',
  },
  merchantDetailsForm4: {
    // Basic Form validation rules
    restaurant_name: 'required',
    restaurant_address: 'required',
    email: 'required',
    mobile_number: 'required',
    password: 'required',
    // Form 1 validation rules
    business_type: 'required',
    locations: 'required',
    first_name: 'required',
    last_name: 'required',
    phone_number: 'required',
    business_email: 'required',
    // Form 2 validation rules
    menu_website: 'required',
    delivery_available: 'required',
    // delivery_charges: 'required_when:delivery_available,1',
    menu_website: 'required',
    opening_hours: 'required',

    legal_business_name: 'required',
    vat_number: 'required|number',
    legal_name: 'required',
    date_of_birth: 'required',
    sort_code: 'required|number',
    bank_name: 'required',
    account_number: 'required|number',
  },
}