'use strict'
module.exports = {

    merchantDetailsForm1: {
      'restaurant_name.required': 'Kindly go back and fill form 1',
      'restaurant_address.required': 'Kindly go back and fill form 1',
      'email.required': 'Kindly go back and fill form 1',
      'mobile_number.required': 'Kindly go back and fill form 1',
      'password.required': 'Kindly go back and fill form 1',



      'required': '{{ field }} is required',
      'max': 'Maximum length allowed for {{ field }} is {{ argument.0 }}',
      'min': '{{ field }} must contain at least {{ argument.0 }} characters',
      'number': 'Only numbers are allowed for {{ field }}',
      'email': '{{ field }} must be a valid email',
      'email.unique': '{{ field }} already registered',
      }, 
      merchantDetailsForm2: 
      {
                // Basic Form validation rules
          'restaurant_name.required': 'Kindly go back and fill form 1',
          'restaurant_address.required': 'Kindly go back and fill form 1',
          'email.required': 'Kindly go back and fill form 1',
          'mobile_number.required': 'Kindly go back and fill form 1',
          'password.required': 'Kindly go back and fill form 1',
          // Form 1 validation rules
          'business_type.required': 'Kindly go back and fill form 2',
          'locations.required': 'Kindly go back and fill form 2',
          'first_name.required': 'Kindly go back and fill form 2',
          'last_name.required': 'Kindly go back and fill form 2',
          'phone_number.required': 'Kindly go back and fill form 2',
          'business_email.required': 'Kindly go back and fill form 2',
          // Form 2 Validations
          'required': '{{ field }} is required',
          'delivery_charges.required_when': 'If you operate delivery then kindly provide delivery charges'
      }, 
      merchantDetailsForm4: 
      {
                // Basic Form validation rules
          'restaurant_name.required': 'Kindly go back and fill form 1',
          'restaurant_address.required': 'Kindly go back and fill form 1',
          'email.required': 'Kindly go back and fill form 1',
          'mobile_number.required': 'Kindly go back and fill form 1',
          'password.required': 'Kindly go back and fill form 1',
          // Form 1 validation rules
          'business_type.required': 'Kindly go back and fill form 2',
          'locations.required': 'Kindly go back and fill form 2',
          'first_name.required': 'Kindly go back and fill form 2',
          'last_name.required': 'Kindly go back and fill form 2',
          'phone_number.required': 'Kindly go back and fill form 2',
          'business_email.required': 'Kindly go back and fill form 2',
          // Form 2 Validations
          'menu_website.required': 'required',
          'delivery_available.required': 'required',
          'delivery_charges.required': 'required_when:delivery_available,1',
          'menu_website.required': 'required',
          'opening_hours.required': 'required',

          'required': '{{ field }} is required',
        },
    
}