-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: localhost    Database: coffee-run
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `menus`
--

DROP TABLE IF EXISTS `menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menus` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned DEFAULT NULL,
  `category_id` int unsigned DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `is_deleted` tinyint(1) DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `menus_user_id_foreign` (`user_id`),
  KEY `menus_category_id_foreign` (`category_id`),
  CONSTRAINT `menus_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `menu_categories` (`id`),
  CONSTRAINT `menus_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menus`
--

LOCK TABLES `menus` WRITE;
/*!40000 ALTER TABLE `menus` DISABLE KEYS */;
INSERT INTO `menus` VALUES (1,4,1,'Chocolate Coffee','Chocolate Coffee Chocolate Coffee Chocolate Coffee updated','12','/uploads/merchant/menu/1622750188418_110.jpeg',0,'2021-04-18 00:40:08','2021-05-02 15:24:29'),(2,4,2,'Ice Cake Coffee ','Ice Cake Coffee Ice Cake Coffee Ice Cake Coffee ','45','/uploads/merchant/menu/1622750611054_265.jpeg',2,'2021-04-18 00:43:29','2021-05-02 15:24:33'),(3,4,2,'Cake Cffee','Cake Cffee Cake Cffee Cake Cffee ','36','/uploads/merchant/menu/1622750682968_581.jpeg',1,'2021-04-18 00:47:10','2021-05-02 15:24:40'),(4,4,4,'Donuts ','Donuts Donuts Donuts Donuts Donuts ','67','/uploads/merchant/menu/1622751017612_453.jpeg',0,'2021-04-18 01:12:17','2021-04-18 01:12:17'),(5,5,5,'Cake','Cake by Merchant 2 Cake by Merchant 2 Cake by Merchant 2 ','60','/uploads/merchant/menu/1618692548364.jpeg',0,'2021-04-18 01:49:08','2021-04-18 01:49:08'),(6,5,6,'Biscuites','Biscuites by Merchant 2 Biscuites by Merchant 2 Biscuites by Merchant 2 ','45','/uploads/merchant/menu/1618692583341.jpeg',0,'2021-04-18 01:49:43','2021-04-18 01:49:43'),(7,5,7,'Hot Coffee 2','Hot Coffee by merchant 2 Hot Coffee by merchant 2 ','56','/uploads/merchant/menu/1618692707614.jpeg',0,'2021-04-18 01:51:47','2021-04-18 01:51:47'),(8,5,7,'Green Coffee ','Green Coffee  Green Coffee  Green Coffee  ','35','/uploads/merchant/menu/1618692739966.jpeg',0,'2021-04-18 01:52:19','2021-04-18 01:52:19');
/*!40000 ALTER TABLE `menus` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-09-02 20:43:23
