-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: localhost    Database: coffee-run
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `merchant_business_hours`
--

DROP TABLE IF EXISTS `merchant_business_hours`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `merchant_business_hours` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned DEFAULT NULL,
  `week_day_id` int unsigned DEFAULT NULL,
  `start_time` varchar(50) NOT NULL,
  `end_time` varchar(50) NOT NULL,
  `is_open` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `merchant_business_hours_user_id_foreign` (`user_id`),
  KEY `merchant_business_hours_week_day_id_foreign` (`week_day_id`),
  CONSTRAINT `merchant_business_hours_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `merchant_business_hours_week_day_id_foreign` FOREIGN KEY (`week_day_id`) REFERENCES `week_days` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `merchant_business_hours`
--

LOCK TABLES `merchant_business_hours` WRITE;
/*!40000 ALTER TABLE `merchant_business_hours` DISABLE KEYS */;
INSERT INTO `merchant_business_hours` VALUES (67,6,1,'02 AM','02 AM',1,'2021-04-18 16:03:25','2021-04-18 16:03:25'),(68,6,2,'02 AM','02 AM',1,'2021-04-18 16:03:25','2021-04-18 16:03:25'),(69,6,3,'12 AM','12 AM',0,'2021-04-18 16:03:25','2021-04-18 16:03:25'),(70,6,4,'12 AM','12 AM',0,'2021-04-18 16:03:26','2021-04-18 16:03:26'),(71,6,5,'12 AM','12 AM',0,'2021-04-18 16:03:26','2021-04-18 16:03:26'),(72,6,6,'03 AM','05 PM',0,'2021-04-18 16:03:26','2021-04-18 16:03:26'),(73,6,7,'05 PM','05 PM',1,'2021-04-18 16:03:26','2021-04-18 16:03:26'),(81,5,1,'03 AM','08 PM',0,'2021-04-18 16:04:40','2021-04-18 16:04:40'),(82,5,2,'12 AM','12 AM',0,'2021-04-18 16:04:40','2021-04-18 16:04:40'),(83,5,3,'03 PM','03 PM',0,'2021-04-18 16:04:40','2021-04-18 16:04:40'),(84,5,4,'06 PM','06 PM',1,'2021-04-18 16:04:40','2021-04-18 16:04:40'),(85,5,5,'12 AM','12 AM',0,'2021-04-18 16:04:40','2021-04-18 16:04:40'),(86,5,6,'12 AM','12 AM',0,'2021-04-18 16:04:40','2021-04-18 16:04:40'),(87,5,7,'03 AM','03 AM',0,'2021-04-18 16:04:40','2021-04-18 16:04:40'),(88,4,1,'01 AM','07 AM',0,'2021-04-18 16:05:31','2021-04-18 16:05:31'),(89,4,2,'02 AM','07 AM',0,'2021-04-18 16:05:31','2021-04-18 16:05:31'),(90,4,3,'12 AM','05 PM',0,'2021-04-18 16:05:31','2021-04-18 16:05:31'),(91,4,4,'07 AM','03 PM',0,'2021-04-18 16:05:31','2021-04-18 16:05:31'),(92,4,5,'05 AM','11 PM',0,'2021-04-18 16:05:31','2021-04-18 16:05:31'),(93,4,6,'05 AM','10 PM',0,'2021-04-18 16:05:32','2021-04-18 16:05:32'),(94,4,7,'02 AM','07 PM',1,'2021-04-18 16:05:32','2021-04-18 16:05:32');
/*!40000 ALTER TABLE `merchant_business_hours` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-09-02 20:43:24
