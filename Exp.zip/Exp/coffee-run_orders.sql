-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: localhost    Database: coffee-run
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned DEFAULT NULL,
  `merchant_id` int unsigned DEFAULT NULL,
  `delivery_address` varchar(255) DEFAULT NULL,
  `cutlery_info` varchar(500) DEFAULT NULL,
  `amount` int DEFAULT NULL,
  `is_completed` int DEFAULT NULL,
  `stripe_session` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `time_required` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `orders_user_id_foreign` (`user_id`),
  KEY `orders_merchant_id_foreign` (`merchant_id`),
  KEY `orders_time_required_foreign` (`time_required`),
  CONSTRAINT `orders_merchant_id_foreign` FOREIGN KEY (`merchant_id`) REFERENCES `users` (`id`),
  CONSTRAINT `orders_time_required_foreign` FOREIGN KEY (`time_required`) REFERENCES `order_times` (`id`),
  CONSTRAINT `orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (1,4,4,'Oval, London SE11 5BU, UK',NULL,100,0,'{\"id\":\"cs_test_b1Z14Lg8y2iCwymq7qLszWh2Nk72sk0EKPdDYAhZGgk3RpxdoReBh4iPJT\",\"object\":\"checkout.session\",\"allow_promotion_codes\":null,\"amount_subtotal\":10200,\"amount_total\":10200,\"billing_address_collection\":null,\"cancel_url\":\"http://127.0.0.1:5672/payment-cancel\",\"client_reference_id\":null,\"currency\":\"usd\",\"customer\":\"cus_JKD3kIAsM2zZIE\",\"customer_details\":{\"email\":\"testing-customer@coffeerun.com\",\"tax_exempt\":\"none\",\"tax_ids\":[]},\"customer_email\":null,\"line_items\":{\"object\":\"list\",\"data\":[{\"id\":\"li_1IhYcrHcesNADLDeCSwq6uEU\",\"object\":\"item\",\"amount_subtotal\":1200,\"amount_total\":1200,\"currency\":\"usd\",\"description\":\"Chocolate Coffee\",\"price\":{\"id\":\"price_1IhYcrHcesNADLDeSKCT87ui\",\"object\":\"price\",\"active\":false,\"billing_scheme\":\"per_unit\",\"created\":1618744637,\"currency\":\"usd\",\"livemode\":false,\"lookup_key\":null,\"metadata\":{},\"nickname\":null,\"product\":\"prod_JKD25Zm197Nl1j\",\"recurring\":null,\"tiers_mode\":null,\"transform_quantity\":null,\"type\":\"one_time\",\"unit_amount\":1200,\"unit_amount_decimal\":\"1200\"},\"quantity\":1},{\"id\":\"li_1IhYcrHcesNADLDeStEWzWsD\",\"object\":\"item\",\"amount_subtotal\":9000,\"amount_total\":9000,\"currency\":\"usd\",\"description\":\"Ice Cake Coffee\",\"price\":{\"id\":\"price_1IhYcrHcesNADLDekfzZxXWK\",\"object\":\"price\",\"active\":false,\"billing_scheme\":\"per_unit\",\"created\":1618744637,\"currency\":\"usd\",\"livemode\":false,\"lookup_key\":null,\"metadata\":{},\"nickname\":null,\"product\":\"prod_JKD2JXyAxql1r8\",\"recurring\":null,\"tiers_mode\":null,\"transform_quantity\":null,\"type\":\"one_time\",\"unit_amount\":4500,\"unit_amount_decimal\":\"4500\"},\"quantity\":2}],\"has_more\":false,\"url\":\"/v1/checkout/sessions/cs_test_b1Z14Lg8y2iCwymq7qLszWh2Nk72sk0EKPdDYAhZGgk3RpxdoReBh4iPJT/line_items\"},\"livemode\":false,\"locale\":null,\"metadata\":{},\"mode\":\"payment\",\"payment_intent\":\"pi_1IhYcrHcesNADLDegldXtd7N\",\"payment_method_options\":{},\"payment_method_types\":[\"card\"],\"payment_status\":\"paid\",\"setup_intent\":null,\"shipping\":null,\"shipping_address_collection\":null,\"submit_type\":null,\"subscription\":null,\"success_url\":\"http://127.0.0.1:5672/payment-success?id={CHECKOUT_SESSION_ID}\",\"total_details\":{\"amount_discount\":0,\"amount_shipping\":0,\"amount_tax\":0}}','2021-05-06 06:02:31','2021-05-12 01:00:21',4),(4,4,4,'safdfd','This is to test informations',200,0,'{\"id\":\"cs_test_b1Z14Lg8y2iCwymq7qLszWh2Nk72sk0EKPdDYAhZGgk3RpxdoReBh4iPJT\",\"object\":\"checkout.session\",\"allow_promotion_codes\":null,\"amount_subtotal\":10200,\"amount_total\":10200,\"billing_address_collection\":null,\"cancel_url\":\"http://127.0.0.1:5672/payment-cancel\",\"client_reference_id\":null,\"currency\":\"usd\",\"customer\":\"cus_JKD3kIAsM2zZIE\",\"customer_details\":{\"email\":\"testing-customer@coffeerun.com\",\"tax_exempt\":\"none\",\"tax_ids\":[]},\"customer_email\":null,\"line_items\":{\"object\":\"list\",\"data\":[{\"id\":\"li_1IhYcrHcesNADLDeCSwq6uEU\",\"object\":\"item\",\"amount_subtotal\":1200,\"amount_total\":1200,\"currency\":\"usd\",\"description\":\"Chocolate Coffee\",\"price\":{\"id\":\"price_1IhYcrHcesNADLDeSKCT87ui\",\"object\":\"price\",\"active\":false,\"billing_scheme\":\"per_unit\",\"created\":1618744637,\"currency\":\"usd\",\"livemode\":false,\"lookup_key\":null,\"metadata\":{},\"nickname\":null,\"product\":\"prod_JKD25Zm197Nl1j\",\"recurring\":null,\"tiers_mode\":null,\"transform_quantity\":null,\"type\":\"one_time\",\"unit_amount\":1200,\"unit_amount_decimal\":\"1200\"},\"quantity\":1},{\"id\":\"li_1IhYcrHcesNADLDeStEWzWsD\",\"object\":\"item\",\"amount_subtotal\":9000,\"amount_total\":9000,\"currency\":\"usd\",\"description\":\"Ice Cake Coffee\",\"price\":{\"id\":\"price_1IhYcrHcesNADLDekfzZxXWK\",\"object\":\"price\",\"active\":false,\"billing_scheme\":\"per_unit\",\"created\":1618744637,\"currency\":\"usd\",\"livemode\":false,\"lookup_key\":null,\"metadata\":{},\"nickname\":null,\"product\":\"prod_JKD2JXyAxql1r8\",\"recurring\":null,\"tiers_mode\":null,\"transform_quantity\":null,\"type\":\"one_time\",\"unit_amount\":4500,\"unit_amount_decimal\":\"4500\"},\"quantity\":2}],\"has_more\":false,\"url\":\"/v1/checkout/sessions/cs_test_b1Z14Lg8y2iCwymq7qLszWh2Nk72sk0EKPdDYAhZGgk3RpxdoReBh4iPJT/line_items\"},\"livemode\":false,\"locale\":null,\"metadata\":{},\"mode\":\"payment\",\"payment_intent\":\"pi_1IhYcrHcesNADLDegldXtd7N\",\"payment_method_options\":{},\"payment_method_types\":[\"card\"],\"payment_status\":\"paid\",\"setup_intent\":null,\"shipping\":null,\"shipping_address_collection\":null,\"submit_type\":null,\"subscription\":null,\"success_url\":\"http://127.0.0.1:5672/payment-success?id={CHECKOUT_SESSION_ID}\",\"total_details\":{\"amount_discount\":0,\"amount_shipping\":0,\"amount_tax\":0}}','2021-05-07 18:21:35','2021-05-02 23:52:03',2),(5,4,4,'sadfsaf',NULL,300,0,'{\"id\":\"cs_test_b1Z14Lg8y2iCwymq7qLszWh2Nk72sk0EKPdDYAhZGgk3RpxdoReBh4iPJT\",\"object\":\"checkout.session\",\"allow_promotion_codes\":null,\"amount_subtotal\":10200,\"amount_total\":10200,\"billing_address_collection\":null,\"cancel_url\":\"http://127.0.0.1:5672/payment-cancel\",\"client_reference_id\":null,\"currency\":\"usd\",\"customer\":\"cus_JKD3kIAsM2zZIE\",\"customer_details\":{\"email\":\"testing-customer@coffeerun.com\",\"tax_exempt\":\"none\",\"tax_ids\":[]},\"customer_email\":null,\"line_items\":{\"object\":\"list\",\"data\":[{\"id\":\"li_1IhYcrHcesNADLDeCSwq6uEU\",\"object\":\"item\",\"amount_subtotal\":1200,\"amount_total\":1200,\"currency\":\"usd\",\"description\":\"Chocolate Coffee\",\"price\":{\"id\":\"price_1IhYcrHcesNADLDeSKCT87ui\",\"object\":\"price\",\"active\":false,\"billing_scheme\":\"per_unit\",\"created\":1618744637,\"currency\":\"usd\",\"livemode\":false,\"lookup_key\":null,\"metadata\":{},\"nickname\":null,\"product\":\"prod_JKD25Zm197Nl1j\",\"recurring\":null,\"tiers_mode\":null,\"transform_quantity\":null,\"type\":\"one_time\",\"unit_amount\":1200,\"unit_amount_decimal\":\"1200\"},\"quantity\":1},{\"id\":\"li_1IhYcrHcesNADLDeStEWzWsD\",\"object\":\"item\",\"amount_subtotal\":9000,\"amount_total\":9000,\"currency\":\"usd\",\"description\":\"Ice Cake Coffee\",\"price\":{\"id\":\"price_1IhYcrHcesNADLDekfzZxXWK\",\"object\":\"price\",\"active\":false,\"billing_scheme\":\"per_unit\",\"created\":1618744637,\"currency\":\"usd\",\"livemode\":false,\"lookup_key\":null,\"metadata\":{},\"nickname\":null,\"product\":\"prod_JKD2JXyAxql1r8\",\"recurring\":null,\"tiers_mode\":null,\"transform_quantity\":null,\"type\":\"one_time\",\"unit_amount\":4500,\"unit_amount_decimal\":\"4500\"},\"quantity\":2}],\"has_more\":false,\"url\":\"/v1/checkout/sessions/cs_test_b1Z14Lg8y2iCwymq7qLszWh2Nk72sk0EKPdDYAhZGgk3RpxdoReBh4iPJT/line_items\"},\"livemode\":false,\"locale\":null,\"metadata\":{},\"mode\":\"payment\",\"payment_intent\":\"pi_1IhYcrHcesNADLDegldXtd7N\",\"payment_method_options\":{},\"payment_method_types\":[\"card\"],\"payment_status\":\"paid\",\"setup_intent\":null,\"shipping\":null,\"shipping_address_collection\":null,\"submit_type\":null,\"subscription\":null,\"success_url\":\"http://127.0.0.1:5672/payment-success?id={CHECKOUT_SESSION_ID}\",\"total_details\":{\"amount_discount\":0,\"amount_shipping\":0,\"amount_tax\":0}}','2021-05-08 18:34:10','2021-05-12 01:00:06',8);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-09-02 20:43:23
