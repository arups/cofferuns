-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: localhost    Database: coffee-run
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `merchant_details`
--

DROP TABLE IF EXISTS `merchant_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `merchant_details` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned DEFAULT NULL,
  `is_activated` tinyint(1) DEFAULT '0',
  `is_business_hours` tinyint NOT NULL DEFAULT '0',
  `restaurant_name` varchar(255) DEFAULT NULL,
  `restaurant_address` varchar(255) DEFAULT NULL,
  `restaurant_lat` varchar(60) DEFAULT NULL,
  `restaurant_lng` varchar(60) DEFAULT NULL,
  `zip_code` varchar(60) DEFAULT NULL,
  `business_type` varchar(255) DEFAULT NULL,
  `locations` varchar(255) DEFAULT NULL,
  `phone_number` int DEFAULT NULL,
  `business_email` varchar(255) DEFAULT NULL,
  `menu_website` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `delivery_available` varchar(10) DEFAULT NULL,
  `delivery_charges` varchar(255) DEFAULT NULL,
  `opening_hours` varchar(255) DEFAULT NULL,
  `legal_business_name` varchar(255) DEFAULT NULL,
  `vat_number` int DEFAULT NULL,
  `legal_name` varchar(255) DEFAULT NULL,
  `date_of_birth` varchar(255) DEFAULT NULL,
  `sort_code` varchar(255) DEFAULT NULL,
  `bank_name` varchar(255) DEFAULT NULL,
  `account_number` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `merchant_details_user_id_foreign` (`user_id`),
  CONSTRAINT `merchant_details_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `merchant_details`
--

LOCK TABLES `merchant_details` WRITE;
/*!40000 ALTER TABLE `merchant_details` DISABLE KEYS */;
INSERT INTO `merchant_details` VALUES (1,4,1,1,'Merchant','Helipad 01, Vauxhall, London SE11 5SL, UK','51.48458781519387','-0.1170390366081131','SE11 5SL','national','6-15',123456,'abc1@xyz.com','wibsiteurl','/uploads/merchant/1618686049789.jpeg','0',NULL,' asdasdasdasd','Business Name 1',124578,'Business Owner\'s Legal Name 1','2021-04-19','12121221','Bank Name','123111','2021-04-18 00:19:51','2021-04-18 01:29:54'),(2,5,1,1,'Merchant 2','Alverstone House, Kennington Park Rd, Oval, London SE11 5TR, UK','51.482835819023634','-0.11261763691608584','SE11 5TR','national','6-15',3434242,'abc2@xyz.com','Promote Website','/uploads/merchant/1618691505957.jpeg','1','12','1213','Legal Business Name 2',1212,'Business Owner\'s Legal Name 2','2021-04-18','234234234','Bank Al Habib ','324234','2021-04-18 01:32:08','2021-04-18 01:32:08'),(3,6,1,1,'Restaurant 1 12','Lohmann House, Kennington Oval, Oval, London SE11 5BU, UK','51.484214822214504','-0.1134009899702293','SE11 5BU','Online','30+',222222,'abc3@xyz.com','website url','/uploads/merchant/1618741232723.jpeg','1','45','aadsad ','Legal Business Name',1234,'Business Owner\'s Legal Name 3','2021-04-22','123456','Bank Al Habib ','12345','2021-04-18 15:20:59','2021-05-02 07:05:45');
/*!40000 ALTER TABLE `merchant_details` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-09-02 20:43:22
