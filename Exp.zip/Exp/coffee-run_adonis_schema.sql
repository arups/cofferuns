-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: localhost    Database: coffee-run
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `adonis_schema`
--

DROP TABLE IF EXISTS `adonis_schema`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `adonis_schema` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `batch` int DEFAULT NULL,
  `migration_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adonis_schema`
--

LOCK TABLES `adonis_schema` WRITE;
/*!40000 ALTER TABLE `adonis_schema` DISABLE KEYS */;
INSERT INTO `adonis_schema` VALUES (1,'1503248427874_role_schema',1,'2021-04-17 13:14:01'),(2,'1503248427885_user',1,'2021-04-17 13:14:02'),(3,'1503248427886_token',1,'2021-04-17 13:14:04'),(4,'1615554009306_business_customer_schema',1,'2021-04-17 13:14:06'),(5,'1615712524826_merchant_details_schema',1,'2021-04-17 13:14:07'),(6,'1615965097441_menu_categories_schema',1,'2021-04-17 13:14:08'),(7,'1615965097442_menu_schema',1,'2021-04-17 13:14:10'),(8,'1616258204614_hours_schema',1,'2021-04-17 13:14:10'),(9,'1616258390055_week_days_schema',1,'2021-04-17 13:14:11'),(10,'1616260180490_merchant_business_hours_schema',1,'2021-04-17 13:14:13'),(11,'1616666164679_orders_schema',1,'2021-04-17 13:14:15'),(12,'1616666164689_orders_items_schema',1,'2021-04-17 13:14:18'),(13,'1616666164699_order_add_column_cutlery_info_schema',2,'2021-05-02 00:11:41'),(14,'1616666164789_order_add_column_is_completed_schema',3,'2021-05-02 17:45:52'),(15,'1616666164789_picker_schema',4,'2021-05-02 18:37:39'),(16,'1616666164790_add_column_order_amount_schema',5,'2021-05-05 20:11:14'),(27,'1616666164791_order_time_schema',6,'2021-05-11 18:53:52'),(28,'1616666164792_add_column_order_order_time_schema',6,'2021-05-11 18:53:53');
/*!40000 ALTER TABLE `adonis_schema` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-09-02 20:43:24
